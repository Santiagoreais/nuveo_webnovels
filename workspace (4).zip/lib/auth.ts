import 'server-only'
import { cookies } from 'next/headers'
import { db } from '@/db'
import { users, sessions } from '@/db/schema'
import { eq, and, gt } from 'drizzle-orm'

const COOKIE_NAME = 'nuveo_sid'
const SESSION_DAYS = 30

export type SessionUser = {
  id: number
  name: string
  username: string
  email: string
  role: 'reader' | 'author' | 'admin'
  avatarUrl: string | null
}

// Gera token seguro usando Node.js crypto (sem Web Crypto)
function generateToken(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let token = ''
  // Usa Math.random como fallback seguro para token de sessão
  for (let i = 0; i < 64; i++) {
    token += chars[Math.floor(Math.random() * chars.length)]
  }
  return token
}

// Usa Node crypto se disponível, senão usa fallback
async function secureToken(): Promise<string> {
  try {
    const { randomBytes } = await import('crypto')
    return randomBytes(32).toString('hex')
  } catch {
    return generateToken()
  }
}

// --- Password hashing simples com Node crypto ---

export async function hashPassword(password: string): Promise<string> {
  const { createHmac, randomBytes } = await import('crypto')
  const salt = randomBytes(16).toString('hex')
  const hash = createHmac('sha256', salt).update(password).digest('hex')
  return `${salt}:${hash}`
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const { createHmac } = await import('crypto')
  const [salt, hash] = stored.split(':')
  if (!salt || !hash) return false
  const check = createHmac('sha256', salt).update(password).digest('hex')
  return check === hash
}

// --- Sessão ---

export async function createSession(user: SessionUser): Promise<void> {
  const token = await secureToken()
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000)

  // Salva sessão no banco
  await db.insert(sessions).values({
    token,
    userId: user.id,
    expiresAt,
  })

  const jar = await cookies()
  jar.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: false, // em dev não precisa de HTTPS
    sameSite: 'lax',
    maxAge: SESSION_DAYS * 24 * 60 * 60,
    path: '/',
  })
}

export async function destroySession(): Promise<void> {
  const jar = await cookies()
  const token = jar.get(COOKIE_NAME)?.value
  if (token) {
    await db.delete(sessions).where(eq(sessions.token, token)).catch(() => {})
  }
  jar.set(COOKIE_NAME, '', { maxAge: 0, path: '/' })
}

export async function getSession(): Promise<SessionUser | null> {
  try {
    const jar = await cookies()
    const token = jar.get(COOKIE_NAME)?.value
    if (!token) return null

    const now = new Date()

    const [row] = await db
      .select({
        id: users.id,
        name: users.name,
        username: users.username,
        email: users.email,
        role: users.role,
        avatarUrl: users.avatarUrl,
        expiresAt: sessions.expiresAt,
      })
      .from(sessions)
      .innerJoin(users, eq(sessions.userId, users.id))
      .where(and(eq(sessions.token, token), gt(sessions.expiresAt, now)))
      .limit(1)

    if (!row) return null

    return {
      id: row.id,
      name: row.name,
      username: row.username,
      email: row.email,
      role: row.role,
      avatarUrl: row.avatarUrl,
    }
  } catch (err) {
    console.error('[getSession error]', err)
    return null
  }
}

export function requireRole(
  user: SessionUser | null,
  role: 'reader' | 'author' | 'admin'
): boolean {
  if (!user) return false
  const hierarchy = { reader: 0, author: 1, admin: 2 }
  return hierarchy[user.role] >= hierarchy[role]
}
