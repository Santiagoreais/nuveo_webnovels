import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function slugify(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

export function generateSlug(title: string): string {
  const base = slugify(title)
  const suffix = Math.random().toString(36).slice(2, 7)
  return `${base}-${suffix}`
}

export function formatDate(date: Date | string): string {
  return new Date(date).toLocaleDateString('pt-BR', {
    day: '2-digit', month: 'short', year: 'numeric',
  })
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}k`
  return String(n)
}

export function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length
}

export const GENRE_LABELS: Record<string, string> = {
  fantasia: 'Fantasia',
  alta_fantasia: 'Alta Fantasia',
  fantasia_urbana: 'Fantasia Urbana',
  fantasia_sombria: 'Fantasia Sombria',
  ficcao_cientifica: 'Ficção Científica',
  acao: 'Ação',
  aventura: 'Aventura',
  romance: 'Romance',
  drama: 'Drama',
  misterio: 'Mistério',
  horror: 'Horror',
  suspense: 'Suspense',
  comedia: 'Comédia',
  isekais: 'Isekai',
  gamelit: 'GameLit',
  litrpg: 'LitRPG',
  xianxia: 'Xianxia',
  xuanhuan: 'Xuanhuan',
  sobrenatural: 'Sobrenatural',
  historico: 'Histórico',
  militar: 'Militar',
  psicologico: 'Psicológico',
  vida_cotidiana: 'Vida Cotidiana',
  vida_escolar: 'Vida Escolar',
  tragedia: 'Tragédia',
  outros: 'Outros',
}

export const STATUS_LABELS: Record<string, string> = {
  active: 'Ativa',
  completed: 'Concluída',
  hiatus: 'Hiato',
  cancelled: 'Cancelada',
}

export const STATUS_COLORS: Record<string, string> = {
  active: 'text-emerald-400 bg-emerald-400/10',
  completed: 'text-blue-400 bg-blue-400/10',
  hiatus: 'text-yellow-400 bg-yellow-400/10',
  cancelled: 'text-red-400 bg-red-400/10',
}
