import {
  pgTable,
  text,
  integer,
  timestamp,
  serial,
  boolean,
  date,
  unique,
  pgEnum,
} from 'drizzle-orm/pg-core'
import { relations } from 'drizzle-orm'

// Enums
export const userRoleEnum = pgEnum('user_role', ['reader', 'author', 'admin'])
export const novelStatusEnum = pgEnum('novel_status', ['active', 'completed', 'hiatus', 'cancelled'])
export const novelGenreEnum = pgEnum('novel_genre', [
  'fantasia', 'alta_fantasia', 'fantasia_urbana', 'fantasia_sombria',
  'ficcao_cientifica', 'acao', 'aventura', 'romance', 'drama',
  'misterio', 'horror', 'suspense', 'comedia', 'isekais',
  'gamelit', 'litrpg', 'xianxia', 'xuanhuan',
  'sobrenatural', 'historico', 'militar', 'psicologico',
  'vida_cotidiana', 'vida_escolar', 'tragedia', 'outros'
])

// Tables
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  username: text('username').notNull().unique(),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  role: userRoleEnum('role').notNull().default('reader'),
  avatarUrl: text('avatar_url'),
  bio: text('bio'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

export const novels = pgTable('novels', {
  id: serial('id').primaryKey(),
  authorId: integer('author_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  title: text('title').notNull(),
  slug: text('slug').notNull().unique(),
  description: text('description').notNull(),
  coverUrl: text('cover_url'),
  genre: novelGenreEnum('genre').notNull().default('outros'),
  tags: text('tags'),
  status: novelStatusEnum('status').notNull().default('active'),
  views: integer('views').notNull().default(0),
  wordCount: integer('word_count').notNull().default(0),
  publishedAt: timestamp('published_at').defaultNow(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

export const chapters = pgTable('chapters', {
  id: serial('id').primaryKey(),
  novelId: integer('novel_id').notNull().references(() => novels.id, { onDelete: 'cascade' }),
  number: integer('number').notNull(),
  title: text('title').notNull(),
  content: text('content').notNull(),
  wordCount: integer('word_count').notNull().default(0),
  isDraft: boolean('is_draft').notNull().default(false),
  views: integer('views').notNull().default(0),
  publishedAt: timestamp('published_at').defaultNow(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

export const comments = pgTable('comments', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  novelId: integer('novel_id').notNull().references(() => novels.id, { onDelete: 'cascade' }),
  chapterId: integer('chapter_id').references(() => chapters.id, { onDelete: 'cascade' }),
  parentId: integer('parent_id'),
  content: text('content').notNull(),
  isDeleted: boolean('is_deleted').notNull().default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

export const votes = pgTable('votes', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  novelId: integer('novel_id').notNull().references(() => novels.id, { onDelete: 'cascade' }),
  value: integer('value').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (t) => [unique().on(t.userId, t.novelId)])

export const hypes = pgTable('hypes', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  novelId: integer('novel_id').notNull().references(() => novels.id, { onDelete: 'cascade' }),
  hypeDate: date('hype_date').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (t) => [unique().on(t.userId, t.novelId, t.hypeDate)])

export const bookmarks = pgTable('bookmarks', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  novelId: integer('novel_id').notNull().references(() => novels.id, { onDelete: 'cascade' }),
  lastChapterId: integer('last_chapter_id').references(() => chapters.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (t) => [unique().on(t.userId, t.novelId)])

export const sessions = pgTable('sessions', {
  id: serial('id').primaryKey(),
  token: text('token').notNull().unique(),
  userId: integer('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  novels: many(novels),
  comments: many(comments),
  votes: many(votes),
  hypes: many(hypes),
  bookmarks: many(bookmarks),
}))

export const novelsRelations = relations(novels, ({ one, many }) => ({
  author: one(users, { fields: [novels.authorId], references: [users.id] }),
  chapters: many(chapters),
  comments: many(comments),
  votes: many(votes),
  hypes: many(hypes),
  bookmarks: many(bookmarks),
}))

export const chaptersRelations = relations(chapters, ({ one, many }) => ({
  novel: one(novels, { fields: [chapters.novelId], references: [novels.id] }),
  comments: many(comments),
}))

export const commentsRelations = relations(comments, ({ one }) => ({
  user: one(users, { fields: [comments.userId], references: [users.id] }),
  novel: one(novels, { fields: [comments.novelId], references: [novels.id] }),
  chapter: one(chapters, { fields: [comments.chapterId], references: [chapters.id] }),
}))
