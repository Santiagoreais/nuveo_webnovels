'use client'

import { useState } from 'react'
import { User, Save, Loader2, CheckCircle, Lock, Eye, EyeOff } from 'lucide-react'
import ImageUpload from '@/components/ImageUpload'

type Profile = {
  id: number; name: string; username: string; email: string
  bio: string | null; avatarUrl: string | null; role: string
}

export default function ProfileEditClient({ profile }: { profile: Profile }) {
  const [name, setName] = useState(profile.name)
  const [bio, setBio] = useState(profile.bio ?? '')
  const [avatarUrl, setAvatarUrl] = useState(profile.avatarUrl ?? '')
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState('')

  const [currentPw, setCurrentPw] = useState('')
  const [newPw, setNewPw] = useState('')
  const [confirmPw, setConfirmPw] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [pwLoading, setPwLoading] = useState(false)
  const [pwMsg, setPwMsg] = useState<{ ok: boolean; text: string } | null>(null)

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true); setError(''); setSaved(false)
    try {
      const res = await fetch('/api/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, bio, avatarUrl }),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error ?? 'Erro ao salvar'); return }
      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    } finally {
      setSaving(false)
    }
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault()
    if (newPw !== confirmPw) { setPwMsg({ ok: false, text: 'Senhas não coincidem' }); return }
    if (newPw.length < 6) { setPwMsg({ ok: false, text: 'Mínimo 6 caracteres' }); return }
    setPwLoading(true); setPwMsg(null)
    try {
      const res = await fetch('/api/profile/password', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword: currentPw, newPassword: newPw }),
      })
      const data = await res.json()
      if (!res.ok) { setPwMsg({ ok: false, text: data.error ?? 'Erro' }); return }
      setPwMsg({ ok: true, text: 'Senha alterada com sucesso!' })
      setCurrentPw(''); setNewPw(''); setConfirmPw('')
    } finally {
      setPwLoading(false)
    }
  }

  const roleLabel: Record<string, string> = { reader: 'Leitor', author: 'Autor', admin: 'Administrador' }
  const roleColor: Record<string, string> = {
    admin: 'text-red-400 bg-red-400/10 border border-red-400/20',
    author: 'text-purple-400 bg-purple-400/10 border border-purple-400/20',
    reader: 'text-blue-400 bg-blue-400/10 border border-blue-400/20',
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <h1 className="text-2xl font-bold mb-1">Configurações de Perfil</h1>
      <p className="text-muted-foreground text-sm mb-8">Gerencie suas informações pessoais</p>

      {/* Perfil */}
      <form onSubmit={saveProfile} className="rounded-xl border border-border bg-card p-6 mb-6 space-y-5">
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-primary" />
          <h2 className="font-semibold">Informações Pessoais</h2>
        </div>

        <div className="flex gap-6 items-start">
          <div className="flex flex-col items-center gap-2 flex-shrink-0">
            <ImageUpload value={avatarUrl} onChange={setAvatarUrl} type="avatar" />
            <span className="text-xs text-muted-foreground">Foto</span>
          </div>

          <div className="flex-1 space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1.5">Nome de exibição</label>
              <input
                value={name} onChange={e => setName(e.target.value)}
                required minLength={2} maxLength={60}
                className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 transition-all"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-1.5">Username</label>
                <input value={'@' + profile.username} disabled
                  className="w-full rounded-lg border border-border bg-muted px-3 py-2.5 text-sm text-muted-foreground cursor-not-allowed" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Cargo</label>
                <div className="flex items-center h-10">
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${roleColor[profile.role] ?? ''}`}>
                    {roleLabel[profile.role] ?? profile.role}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1.5">Bio</label>
          <textarea
            value={bio} onChange={e => setBio(e.target.value)} maxLength={500} rows={3}
            placeholder="Conte um pouco sobre você..."
            className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 resize-none transition-all placeholder:text-muted-foreground"
          />
          <p className="text-xs text-muted-foreground mt-1 text-right">{bio.length}/500</p>
        </div>

        {error && <p className="text-sm text-red-400 bg-destructive/10 rounded-lg px-3 py-2">{error}</p>}

        <button type="submit" disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors">
          {saving ? <><Loader2 className="h-4 w-4 animate-spin" />Salvando...</>
            : saved ? <><CheckCircle className="h-4 w-4 text-emerald-300" />Salvo!</>
            : <><Save className="h-4 w-4" />Salvar alterações</>}
        </button>
      </form>

      {/* Senha */}
      <form onSubmit={changePassword} className="rounded-xl border border-border bg-card p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Lock className="h-4 w-4 text-primary" />
          <h2 className="font-semibold">Alterar Senha</h2>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1.5">Senha atual</label>
          <div className="relative">
            <input type={showPw ? 'text' : 'password'} value={currentPw} onChange={e => setCurrentPw(e.target.value)} required
              className="w-full rounded-lg border border-input bg-background px-3 py-2.5 pr-10 text-sm outline-none focus:ring-2 focus:ring-primary/50 transition-all" />
            <button type="button" onClick={() => setShowPw(p => !p)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium mb-1.5">Nova senha</label>
            <input type="password" value={newPw} onChange={e => setNewPw(e.target.value)} required minLength={6}
              className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 transition-all" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Confirmar</label>
            <input type="password" value={confirmPw} onChange={e => setConfirmPw(e.target.value)} required
              className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 transition-all" />
          </div>
        </div>

        {pwMsg && (
          <p className={`text-sm rounded-lg px-3 py-2 ${pwMsg.ok ? 'text-emerald-400 bg-emerald-400/10' : 'text-red-400 bg-destructive/10'}`}>
            {pwMsg.text}
          </p>
        )}

        <button type="submit" disabled={pwLoading}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg border border-border bg-secondary text-sm font-medium hover:bg-accent disabled:opacity-60 transition-colors">
          {pwLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
          Alterar Senha
        </button>
      </form>
    </div>
  )
}
