export const dynamic = 'force-dynamic'
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import { db } from '@/db'
import { users } from '@/db/schema'
import { eq } from 'drizzle-orm'
import ProfileEditClient from './ProfileEditClient'

export default async function ConfiguracoesPage() {
  const user = await getSession()
  if (!user) redirect('/login')

  const [profile] = await db.select({
    id: users.id, name: users.name, username: users.username,
    email: users.email, bio: users.bio, avatarUrl: users.avatarUrl, role: users.role,
  }).from(users).where(eq(users.id, user.id)).limit(1)

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <ProfileEditClient profile={profile} />
    </div>
  )
}
