export const dynamic = 'force-dynamic'
import Link from 'next/link'
import { db } from '@/db'
import { novels, chapters, users } from '@/db/schema'
import { eq, desc } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import { Clock, BookOpen } from 'lucide-react'
import { formatDate } from '@/lib/utils'

async function getRecentChapters() {
  return db.select({
    chapterId: chapters.id,
    chapterNumber: chapters.number,
    chapterTitle: chapters.title,
    chapterWordCount: chapters.wordCount,
    publishedAt: chapters.publishedAt,
    novelId: novels.id,
    novelTitle: novels.title,
    novelSlug: novels.slug,
    novelCover: novels.coverUrl,
    novelGenre: novels.genre,
    authorName: users.name,
  })
    .from(chapters)
    .leftJoin(novels, eq(chapters.novelId, novels.id))
    .leftJoin(users, eq(novels.authorId, users.id))
    .where(eq(chapters.isDraft, false))
    .orderBy(desc(chapters.publishedAt))
    .limit(50)
}

export default async function LancamentosPage() {
  const [user, releases] = await Promise.all([getSession(), getRecentChapters()])

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <div className="mx-auto max-w-4xl px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2.5 rounded-xl bg-primary/10 border border-primary/20">
            <Clock className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Lançamentos Recentes</h1>
            <p className="text-sm text-muted-foreground">Capítulos publicados recentemente</p>
          </div>
        </div>

        {releases.length === 0 ? (
          <div className="text-center py-16 border border-dashed border-border rounded-xl">
            <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Nenhum capítulo publicado ainda.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {releases.map(ch => (
              <Link key={ch.chapterId} href={`/historias/${ch.novelSlug}/${ch.chapterNumber}`}
                className="flex items-center gap-4 p-4 rounded-xl border border-border bg-card hover:border-primary/40 hover:bg-accent/30 transition-all group">
                <div className="w-12 h-16 rounded-lg flex-shrink-0 overflow-hidden bg-primary/10">
                  {ch.novelCover ? (
                    <img src={ch.novelCover} alt={ch.novelTitle ?? ''} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full cover-gradient flex items-center justify-center">
                      <BookOpen className="h-4 w-4 text-primary/40" />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm group-hover:text-primary transition-colors truncate">{ch.novelTitle}</p>
                  <p className="text-sm text-muted-foreground truncate">
                    Capítulo {ch.chapterNumber} — {ch.chapterTitle}
                  </p>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                    <span>por {ch.authorName}</span>
                    <span>{ch.chapterWordCount?.toLocaleString()} palavras</span>
                  </div>
                </div>
                <div className="flex-shrink-0 text-right">
                  <p className="text-xs text-muted-foreground">
                    {ch.publishedAt ? formatDate(ch.publishedAt) : ''}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
