export const dynamic = 'force-dynamic'
import { redirect, notFound } from 'next/navigation'
import Link from 'next/link'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import NovelManageClient from './NovelManageClient'
import { db } from '@/db'
import { novels, chapters } from '@/db/schema'
import { eq, and, desc } from 'drizzle-orm'

export default async function NovelManagePage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getSession()
  if (!user) redirect('/login')
  const { id } = await params
  const novelId = parseInt(id)

  const [novel] = await db.select().from(novels).where(eq(novels.id, novelId)).limit(1)
  if (!novel) notFound()
  if (novel.authorId !== user.id && user.role !== 'admin') redirect('/minha-area')

  const chapterList = await db.select().from(chapters)
    .where(eq(chapters.novelId, novelId))
    .orderBy(desc(chapters.number))

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <NovelManageClient novel={novel} initialChapters={chapterList} user={user} />
    </div>
  )
}
