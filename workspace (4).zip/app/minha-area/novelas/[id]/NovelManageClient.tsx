'use client'

import { useState } from 'react'
import Link from 'next/link'
import { PlusCircle, BookOpen, Eye, Loader2, X, FileText, Send } from 'lucide-react'
import { GENRE_LABELS, STATUS_LABELS, STATUS_COLORS, formatDate, cn } from '@/lib/utils'
import ChapterEditor from '@/components/ChapterEditor'

type Novel = {
  id: number; title: string; slug: string; description: string; coverUrl: string | null
  genre: string; tags: string | null; status: string; views: number; authorId: number
}
type Chapter = {
  id: number; number: number; title: string; content: string
  wordCount: number; isDraft: boolean; publishedAt: Date | string | null; views: number
}
type User = { id: number; name: string; role: string }

export default function NovelManageClient({
  novel: initialNovel, initialChapters, user
}: { novel: Novel; initialChapters: Chapter[]; user: User }) {
  const [chapters, setChapters] = useState<Chapter[]>(initialChapters)
  const [showChapterForm, setShowChapterForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [chapterForm, setChapterForm] = useState({ title: '', content: '', isDraft: false })

  function updateChapter(k: string, v: string | boolean) {
    setChapterForm(p => ({ ...p, [k]: v }))
  }

  async function submitChapter(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    setError('')
    try {
      const res = await fetch(`/api/author/novels/${initialNovel.id}/chapters`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(chapterForm),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error ?? 'Erro ao criar capítulo'); return }
      setChapters(p => [data.chapter, ...p])
      setShowChapterForm(false)
      setChapterForm({ title: '', content: '', isDraft: false })
    } finally {
      setSaving(false)
    }
  }

  const publishedCount = chapters.filter(c => !c.isDraft).length
  const draftCount = chapters.filter(c => c.isDraft).length

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1 text-sm text-muted-foreground mb-6">
        <Link href="/minha-area" className="hover:text-primary transition-colors">Minha Área</Link>
        <span className="mx-1">/</span>
        <span className="text-foreground/80 truncate">{initialNovel.title}</span>
      </nav>

      {/* Novel header */}
      <div className="flex flex-col sm:flex-row gap-6 mb-8 p-5 rounded-xl border border-border bg-card">
        <div className="w-24 h-36 rounded-lg flex-shrink-0 overflow-hidden bg-primary/10">
          {initialNovel.coverUrl ? (
            <img src={initialNovel.coverUrl} alt={initialNovel.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full cover-gradient flex items-center justify-center">
              <BookOpen className="h-8 w-8 text-primary/30" />
            </div>
          )}
        </div>
        <div className="flex-1">
          <div className="flex items-start gap-3 mb-2">
            <h1 className="text-xl font-bold">{initialNovel.title}</h1>
            <span className={cn('text-xs font-semibold px-2 py-0.5 rounded-full flex-shrink-0', STATUS_COLORS[initialNovel.status])}>
              {STATUS_LABELS[initialNovel.status]}
            </span>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{initialNovel.description}</p>
          <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
            <span className="text-primary/80 font-medium">{GENRE_LABELS[initialNovel.genre] ?? initialNovel.genre}</span>
            <span className="flex items-center gap-1"><Eye className="h-3 w-3" />{initialNovel.views} views</span>
            <span className="flex items-center gap-1"><BookOpen className="h-3 w-3" />{publishedCount} capítulos</span>
            {draftCount > 0 && <span className="text-yellow-400">{draftCount} rascunho{draftCount > 1 ? 's' : ''}</span>}
          </div>
          <div className="flex gap-2 mt-4">
            <Link href={`/historias/${initialNovel.slug}`}
              className="px-3 py-1.5 rounded-lg border border-border text-xs hover:bg-accent transition-colors">
              Ver página pública
            </Link>
          </div>
        </div>
      </div>

      {/* Chapters section */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-lg">Capítulos ({chapters.length})</h2>
        <button onClick={() => setShowChapterForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
          <PlusCircle className="h-4 w-4" /> Novo Capítulo
        </button>
      </div>

      {/* Chapter form modal */}
      {showChapterForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-3xl rounded-2xl border border-border bg-card shadow-2xl flex flex-col max-h-[95vh]">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border flex-shrink-0">
              <h2 className="font-bold text-lg">Novo Capítulo</h2>
              <button onClick={() => setShowChapterForm(false)} className="p-1 rounded-md hover:bg-accent">
                <X className="h-5 w-5" />
              </button>
            </div>
            <form onSubmit={submitChapter} className="flex flex-col flex-1 overflow-hidden">
              <div className="p-6 space-y-4 flex-1 overflow-y-auto">
                <div>
                  <label className="block text-sm font-medium mb-1.5">Título do Capítulo *</label>
                  <input
                    value={chapterForm.title}
                    onChange={e => updateChapter('title', e.target.value)}
                    required
                    placeholder="Ex: A Grande Batalha"
                    className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Conteúdo *</label>
                  <ChapterEditor
                    value={chapterForm.content}
                    onChange={v => updateChapter('content', v)}
                    placeholder="Comece a escrever seu capítulo..."
                  />
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="isDraft"
                    checked={chapterForm.isDraft}
                    onChange={e => updateChapter('isDraft', e.target.checked)}
                    className="rounded"
                  />
                  <label htmlFor="isDraft" className="text-sm text-muted-foreground cursor-pointer">
                    Salvar como rascunho (não publicar ainda)
                  </label>
                </div>
                {error && <p className="text-sm text-red-400 bg-destructive/10 rounded-lg px-3 py-2">{error}</p>}
              </div>
              <div className="px-6 py-4 border-t border-border flex gap-3 flex-shrink-0">
                <button type="button" onClick={() => setShowChapterForm(false)} className="flex-1 py-2.5 rounded-lg border border-border text-sm font-medium hover:bg-accent transition-colors">
                  Cancelar
                </button>
                <button type="submit" disabled={saving} className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-60 transition-colors">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : chapterForm.isDraft ? <FileText className="h-4 w-4" /> : <Send className="h-4 w-4" />}
                  {chapterForm.isDraft ? 'Salvar Rascunho' : 'Publicar Capítulo'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Chapters list */}
      {chapters.length === 0 ? (
        <div className="text-center py-12 border border-dashed border-border rounded-xl">
          <BookOpen className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
          <p className="font-medium mb-1">Nenhum capítulo ainda</p>
          <p className="text-sm text-muted-foreground mb-5">Comece escrevendo o primeiro capítulo da sua história!</p>
          <button onClick={() => setShowChapterForm(true)} className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
            Escrever Primeiro Capítulo
          </button>
        </div>
      ) : (
        <div className="rounded-xl border border-border overflow-hidden">
          <div className="divide-y divide-border">
            {chapters.map(ch => (
              <div key={ch.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-accent/30 transition-colors">
                <span className="text-sm text-muted-foreground w-8 flex-shrink-0">#{ch.number}</span>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{ch.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{ch.wordCount.toLocaleString()} palavras · {ch.publishedAt ? formatDate(ch.publishedAt) : ''}</p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {ch.isDraft && (
                    <span className="text-xs px-2 py-0.5 rounded bg-yellow-400/10 text-yellow-400 font-medium">Rascunho</span>
                  )}
                  <span className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Eye className="h-3 w-3" />{ch.views}
                  </span>
                  <Link href={`/historias/${initialNovel.slug}/${ch.number}`}
                    className="px-2.5 py-1 rounded text-xs border border-border hover:bg-accent transition-colors">
                    Ver
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
