export const dynamic = 'force-dynamic'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import AuthorDashboardClient from './AuthorDashboardClient'

export default async function MinhaAreaPage() {
  const user = await getSession()
  if (!user) redirect('/login')
  if (user.role === 'reader') {
    return (
      <div className="min-h-screen bg-background">
        <Navbar user={user} />
        <div className="mx-auto max-w-2xl px-4 py-20 text-center">
          <div className="rounded-2xl border border-border bg-card p-10">
            <h1 className="text-2xl font-bold mb-3">Acesso Restrito</h1>
            <p className="text-muted-foreground mb-6">
              Para publicar novelas, você precisa ter o cargo de <strong>Autor</strong>.
              Este cargo é concedido manualmente pelo administrador da plataforma.
            </p>
            <p className="text-sm text-muted-foreground">
              Entre em contato com a administração para solicitar o cargo de autor.
            </p>
          </div>
        </div>
      </div>
    )
  }
  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <AuthorDashboardClient user={user} />
    </div>
  )
}
