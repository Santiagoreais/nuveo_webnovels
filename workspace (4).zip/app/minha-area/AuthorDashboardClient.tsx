'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { PlusCircle, BookOpen, Eye, Star, Flame, Edit, Loader2, X, Check } from 'lucide-react'
import { GENRE_LABELS, STATUS_LABELS, STATUS_COLORS, formatNumber, cn } from '@/lib/utils'
import ImageUpload from '@/components/ImageUpload'

type SessionUser = { id: number; name: string; username: string; role: string; avatarUrl: string | null }

type Novel = {
  id: number; title: string; slug: string; status: string; genre: string
  views: number; chapterCount: number; avgRating: number; hypeCount: number; createdAt: string
}

const GENRES = Object.entries(GENRE_LABELS)
const STATUSES = [
  { value: 'active', label: 'Ativa' },
  { value: 'completed', label: 'Concluída' },
  { value: 'hiatus', label: 'Em Hiato' },
  { value: 'cancelled', label: 'Cancelada' },
]

export default function AuthorDashboardClient({ user }: { user: SessionUser }) {
  const [novels, setNovels] = useState<Novel[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [creating, setCreating] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({
    title: '', description: '', coverUrl: '', genre: 'fantasia', tags: '', status: 'active'
  })

  useEffect(() => {
    fetch('/api/author/novels').then(r => r.json()).then(d => {
      setNovels(d.novels ?? [])
      setLoading(false)
    })
  }, [])

  function updateForm(k: string, v: string) { setForm(p => ({ ...p, [k]: v })) }

  async function createNovel(e: React.FormEvent) {
    e.preventDefault()
    setCreating(true)
    setError('')
    try {
      const res = await fetch('/api/author/novels', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error ?? 'Erro ao criar'); return }
      setNovels(p => [data.novel, ...p])
      setShowForm(false)
      setForm({ title: '', description: '', coverUrl: '', genre: 'fantasia', tags: '', status: 'active' })
    } finally {
      setCreating(false)
    }
  }

  const totalViews = novels.reduce((a, n) => a + n.views, 0)
  const totalHype = novels.reduce((a, n) => a + n.hypeCount, 0)
  const totalChapters = novels.reduce((a, n) => a + n.chapterCount, 0)

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold">Minha Área</h1>
          <p className="text-muted-foreground text-sm mt-1">Gerencie suas webnovels, {user.name}</p>
        </div>
        <button onClick={() => setShowForm(true)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 font-medium text-sm transition-colors">
          <PlusCircle className="h-4 w-4" /> Nova Novel
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        {[
          { icon: <BookOpen className="h-5 w-5 text-primary" />, label: 'Novelas', value: novels.length },
          { icon: <BookOpen className="h-5 w-5 text-blue-400" />, label: 'Capítulos', value: totalChapters },
          { icon: <Eye className="h-5 w-5 text-emerald-400" />, label: 'Visualizações', value: formatNumber(totalViews) },
          { icon: <Flame className="h-5 w-5 text-amber-400" />, label: 'Total Hype', value: formatNumber(totalHype) },
        ].map(s => (
          <div key={s.label} className="rounded-xl border border-border bg-card p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-background">{s.icon}</div>
            <div>
              <p className="text-lg font-bold">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Create Novel Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl border border-border bg-card shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <h2 className="font-bold text-lg">Nova Webnovel</h2>
              <button onClick={() => setShowForm(false)} className="p-1 rounded-md hover:bg-accent transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>
            <form onSubmit={createNovel} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Título *</label>
                <input value={form.title} onChange={e => updateForm('title', e.target.value)} required
                  className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                  placeholder="O Título da Sua História" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Sinopse *</label>
                <textarea value={form.description} onChange={e => updateForm('description', e.target.value)} required rows={4}
                  className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 resize-none transition-all"
                  placeholder="Descreva sua história em até 5000 caracteres..." />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Capa (opcional)</label>
                <ImageUpload
                  value={form.coverUrl}
                  onChange={v => updateForm('coverUrl', v)}
                  type="cover"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium mb-1.5">Gênero *</label>
                  <select value={form.genre} onChange={e => updateForm('genre', e.target.value)}
                    className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 transition-all">
                    {GENRES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Status</label>
                  <select value={form.status} onChange={e => updateForm('status', e.target.value)}
                    className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 transition-all">
                    {STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Tags (separadas por vírgula)</label>
                <input value={form.tags} onChange={e => updateForm('tags', e.target.value)}
                  className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                  placeholder="magia, aventura, isekai..." />
              </div>
              {error && <p className="text-sm text-red-400 bg-destructive/10 rounded-lg px-3 py-2">{error}</p>}
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-border text-sm font-medium hover:bg-accent transition-colors">
                  Cancelar
                </button>
                <button type="submit" disabled={creating} className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-60 transition-colors">
                  {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                  Criar Novel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Novels list */}
      <div>
        <h2 className="font-semibold mb-4">Minhas Novelas ({novels.length})</h2>
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : novels.length === 0 ? (
          <div className="text-center py-16 border border-dashed border-border rounded-xl">
            <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="font-semibold mb-2">Nenhuma novel ainda</p>
            <p className="text-sm text-muted-foreground mb-6">Clique em "Nova Novel" para começar a sua jornada!</p>
            <button onClick={() => setShowForm(true)} className="px-5 py-2.5 rounded-lg bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors">
              Criar Primeira Novel
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {novels.map(novel => (
              <div key={novel.id} className="flex items-center gap-4 p-4 rounded-xl border border-border bg-card hover:border-primary/30 transition-all">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold truncate">{novel.title}</h3>
                    <span className={cn('text-[10px] px-1.5 py-0.5 rounded font-medium flex-shrink-0', STATUS_COLORS[novel.status])}>
                      {STATUS_LABELS[novel.status]}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span className="text-primary/80">{GENRE_LABELS[novel.genre] ?? novel.genre}</span>
                    <span className="flex items-center gap-1"><BookOpen className="h-3 w-3" />{novel.chapterCount} caps</span>
                    <span className="flex items-center gap-1"><Eye className="h-3 w-3" />{formatNumber(novel.views)}</span>
                    <span className="flex items-center gap-1"><Flame className="h-3 w-3 text-amber-400" />{formatNumber(novel.hypeCount)}</span>
                    <span className="flex items-center gap-1"><Star className="h-3 w-3 text-gold" />{novel.avgRating > 0 ? novel.avgRating.toFixed(1) : '–'}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Link href={`/historias/${novel.slug}`} className="px-3 py-1.5 rounded-lg border border-border text-xs hover:bg-accent transition-colors">
                    Ver
                  </Link>
                  <Link href={`/minha-area/novelas/${novel.id}`} className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-xs hover:bg-primary/20 transition-colors">
                    <Edit className="h-3 w-3" /> Gerenciar
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
