'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Shield, BookOpen, Loader2, CheckCircle, AlertCircle, Eye, EyeOff } from 'lucide-react'

export default function AdminSetupPage() {
  const [username, setUsername] = useState('')
  const [secret, setSecret] = useState('')
  const [showSecret, setShowSecret] = useState(false)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setResult(null)
    try {
      const res = await fetch('/api/admin/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, secret }),
      })
      const data = await res.json()
      if (res.ok) {
        setResult({ ok: true, message: `@${data.user.username} agora é administrador!` })
      } else {
        setResult({ ok: false, message: data.error ?? 'Erro desconhecido' })
      }
    } catch {
      setResult({ ok: false, message: 'Erro de conexão' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/20">
              <BookOpen className="h-5 w-5 text-primary" />
            </div>
            <span className="text-2xl font-bold">
              <span className="text-primary">Nu</span>veo
            </span>
          </Link>
          <div className="flex items-center justify-center gap-2 mb-3">
            <div className="p-2 rounded-xl bg-red-500/10 border border-red-500/20">
              <Shield className="h-6 w-6 text-red-400" />
            </div>
          </div>
          <h1 className="text-2xl font-bold">Setup de Administrador</h1>
          <p className="text-muted-foreground text-sm mt-2 max-w-sm mx-auto">
            Promove um usuário existente a admin. Só funciona se não houver nenhum admin cadastrado ainda.
          </p>
        </div>

        <div className="rounded-xl border border-border bg-card p-6 shadow-xl shadow-black/20">
          {result ? (
            <div className="text-center py-4 space-y-4">
              <div className={`inline-flex items-center justify-center w-14 h-14 rounded-full ${result.ok ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                {result.ok
                  ? <CheckCircle className="h-8 w-8 text-emerald-400" />
                  : <AlertCircle className="h-8 w-8 text-red-400" />
                }
              </div>
              <p className={`font-semibold ${result.ok ? 'text-emerald-400' : 'text-red-400'}`}>
                {result.message}
              </p>
              {result.ok ? (
                <div className="space-y-2 pt-2">
                  <p className="text-sm text-muted-foreground">Faça logout e entre novamente para acessar o painel admin.</p>
                  <Link
                    href="/login"
                    className="inline-block px-5 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
                  >
                    Ir para Login
                  </Link>
                </div>
              ) : (
                <button
                  onClick={() => setResult(null)}
                  className="text-sm text-primary hover:underline"
                >
                  Tentar novamente
                </button>
              )}
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Username do usuário *</label>
                <input
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                  placeholder="username_do_usuario"
                  required
                  className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all placeholder:text-muted-foreground"
                />
                <p className="text-xs text-muted-foreground mt-1">O usuário já deve ter uma conta criada</p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1.5">Segredo de setup *</label>
                <div className="relative">
                  <input
                    type={showSecret ? 'text' : 'password'}
                    value={secret}
                    onChange={e => setSecret(e.target.value)}
                    placeholder="••••••••••••"
                    required
                    className="w-full rounded-lg border border-input bg-background px-3 py-2.5 pr-10 text-sm outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all placeholder:text-muted-foreground"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSecret(p => !p)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Padrão: <code className="bg-muted px-1 py-0.5 rounded text-xs">nuveo-setup-2024</code>
                  {' '}(configure <code className="bg-muted px-1 py-0.5 rounded text-xs">ADMIN_SETUP_SECRET</code> no .env para mudar)
                </p>
              </div>

              <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 px-3 py-2.5">
                <p className="text-xs text-amber-400">
                  ⚠️ Esta rota fica <strong>bloqueada automaticamente</strong> após o primeiro admin ser criado.
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 rounded-lg bg-red-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-red-600 transition-colors disabled:opacity-60"
              >
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                {loading ? 'Promovendo...' : 'Promover a Administrador'}
              </button>
            </form>
          )}
        </div>

        <p className="text-center text-xs text-muted-foreground mt-6">
          <Link href="/" className="hover:text-primary transition-colors">← Voltar ao início</Link>
        </p>
      </div>
    </div>
  )
}
