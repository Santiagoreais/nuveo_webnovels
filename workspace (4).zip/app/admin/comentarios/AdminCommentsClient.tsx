'use client'

import { useState } from 'react'
import Link from 'next/link'
import { MessageCircle, ChevronLeft, Search, Trash2, Loader2, ExternalLink, Eye } from 'lucide-react'
import { formatDate, cn } from '@/lib/utils'

type Comment = {
  id: number; content: string; isDeleted: boolean; createdAt: Date | string
  chapterId: number | null; userName: string | null; userUsername: string | null
  novelTitle: string | null; novelSlug: string | null
}

export default function AdminCommentsClient({ comments: initialComments }: { comments: Comment[] }) {
  const [comments, setComments] = useState<Comment[]>(initialComments)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState<'all' | 'active' | 'deleted'>('all')
  const [deletingId, setDeletingId] = useState<number | null>(null)

  async function toggleDelete(id: number, isDeleted: boolean) {
    setDeletingId(id)
    try {
      const res = await fetch(`/api/admin/comments/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isDeleted: !isDeleted }),
      })
      if (res.ok) setComments(p => p.map(c => c.id === id ? { ...c, isDeleted: !isDeleted } : c))
    } finally {
      setDeletingId(null)
    }
  }

  const filtered = comments.filter(c => {
    const matchSearch = !search ||
      c.content.toLowerCase().includes(search.toLowerCase()) ||
      (c.userName ?? '').toLowerCase().includes(search.toLowerCase()) ||
      (c.novelTitle ?? '').toLowerCase().includes(search.toLowerCase())
    const matchFilter = filter === 'all' || (filter === 'deleted' ? c.isDeleted : !c.isDeleted)
    return matchSearch && matchFilter
  })

  const activeCount = comments.filter(c => !c.isDeleted).length
  const deletedCount = comments.filter(c => c.isDeleted).length

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="flex items-center gap-3 mb-8">
        <Link href="/admin" className="p-2 rounded-lg hover:bg-accent transition-colors text-muted-foreground">
          <ChevronLeft className="h-5 w-5" />
        </Link>
        <div className="p-2.5 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
          <MessageCircle className="h-5 w-5 text-yellow-400" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Moderar Comentários</h1>
          <p className="text-sm text-muted-foreground">{activeCount} ativos · {deletedCount} removidos</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Buscar comentários..."
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-input bg-card text-sm outline-none focus:ring-2 focus:ring-primary/50 placeholder:text-muted-foreground" />
        </div>
        <div className="flex gap-1 p-1 rounded-lg bg-card border border-border">
          {([
            { v: 'all', l: `Todos (${comments.length})` },
            { v: 'active', l: `Ativos (${activeCount})` },
            { v: 'deleted', l: `Removidos (${deletedCount})` },
          ] as const).map(({ v, l }) => (
            <button key={v} onClick={() => setFilter(v)}
              className={cn('px-3 py-1.5 rounded-md text-xs font-medium transition-colors',
                filter === v ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent')}>
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* Comments list */}
      <div className="space-y-2">
        {filtered.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-border rounded-xl text-muted-foreground text-sm">
            Nenhum comentário encontrado.
          </div>
        ) : filtered.map(c => (
          <div key={c.id}
            className={cn('rounded-xl border p-4 transition-colors',
              c.isDeleted ? 'border-border bg-muted/30 opacity-60' : 'border-border bg-card')}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  <span className="font-medium text-sm">{c.userName}</span>
                  <span className="text-xs text-muted-foreground">@{c.userUsername}</span>
                  <span className="text-xs text-muted-foreground">·</span>
                  <span className="text-xs text-muted-foreground">{formatDate(c.createdAt)}</span>
                  {c.isDeleted && (
                    <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-red-400/10 text-red-400">removido</span>
                  )}
                  {c.chapterId && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-400/10 text-blue-400">no capítulo</span>
                  )}
                </div>
                <p className={cn('text-sm leading-relaxed', c.isDeleted ? 'line-through text-muted-foreground' : '')}>
                  {c.content}
                </p>
                {c.novelTitle && (
                  <div className="flex items-center gap-1 mt-2">
                    <span className="text-xs text-muted-foreground">em</span>
                    <Link href={`/historias/${c.novelSlug}`} className="text-xs text-primary hover:underline flex items-center gap-1">
                      {c.novelTitle} <ExternalLink className="h-2.5 w-2.5" />
                    </Link>
                  </div>
                )}
              </div>
              <button
                onClick={() => toggleDelete(c.id, c.isDeleted)}
                disabled={deletingId === c.id}
                className={cn(
                  'flex-shrink-0 p-2 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5',
                  c.isDeleted
                    ? 'bg-emerald-400/10 text-emerald-400 hover:bg-emerald-400/20 border border-emerald-400/20'
                    : 'bg-red-400/10 text-red-400 hover:bg-red-400/20 border border-red-400/20'
                )}>
                {deletingId === c.id
                  ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  : c.isDeleted
                  ? <><Eye className="h-3.5 w-3.5" />Restaurar</>
                  : <><Trash2 className="h-3.5 w-3.5" />Remover</>}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
