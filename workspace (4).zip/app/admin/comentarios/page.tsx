export const dynamic = 'force-dynamic'
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import AdminCommentsClient from './AdminCommentsClient'
import { db } from '@/db'
import { comments, users, novels } from '@/db/schema'
import { eq, desc } from 'drizzle-orm'

export default async function AdminComentariosPage() {
  const user = await getSession()
  if (!user || user.role !== 'admin') redirect('/')

  const allComments = await db
    .select({
      id: comments.id,
      content: comments.content,
      isDeleted: comments.isDeleted,
      createdAt: comments.createdAt,
      chapterId: comments.chapterId,
      userName: users.name,
      userUsername: users.username,
      novelTitle: novels.title,
      novelSlug: novels.slug,
    })
    .from(comments)
    .leftJoin(users, eq(comments.userId, users.id))
    .leftJoin(novels, eq(comments.novelId, novels.id))
    .orderBy(desc(comments.createdAt))
    .limit(200)

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <AdminCommentsClient comments={allComments} />
    </div>
  )
}
