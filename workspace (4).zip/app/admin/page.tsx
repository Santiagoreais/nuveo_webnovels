export const dynamic = 'force-dynamic'
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import AdminDashboard from './AdminDashboard'
import { db } from '@/db'
import { users, novels, chapters, comments, hypes } from '@/db/schema'
import { sql } from 'drizzle-orm'

export default async function AdminPage() {
  const user = await getSession()
  if (!user || user.role !== 'admin') redirect('/')

  const [userStats] = await db.select({ count: sql<number>`count(*)::int` }).from(users)
  const [novelStats] = await db.select({ count: sql<number>`count(*)::int` }).from(novels)
  const [chapterStats] = await db.select({ count: sql<number>`count(*)::int` }).from(chapters)
  const [commentStats] = await db.select({ count: sql<number>`count(*)::int` }).from(comments)
  const [hypeStats] = await db.select({ count: sql<number>`count(*)::int` }).from(hypes)

  const recentUsers = await db.select({
    id: users.id, name: users.name, username: users.username,
    email: users.email, role: users.role, createdAt: users.createdAt,
  }).from(users).orderBy(sql`${users.createdAt} desc`).limit(10)

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <AdminDashboard
        stats={{
          users: userStats.count,
          novels: novelStats.count,
          chapters: chapterStats.count,
          comments: commentStats.count,
          hypes: hypeStats.count,
        }}
        recentUsers={recentUsers}
      />
    </div>
  )
}
