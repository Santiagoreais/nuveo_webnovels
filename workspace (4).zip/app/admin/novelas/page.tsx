export const dynamic = 'force-dynamic'
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import AdminNovelsClient from './AdminNovelsClient'
import { db } from '@/db'
import { novels, users, chapters } from '@/db/schema'
import { sql } from 'drizzle-orm'
import { eq, desc, and } from 'drizzle-orm'

export default async function AdminNovelasPage() {
  const user = await getSession()
  if (!user || user.role !== 'admin') redirect('/')

  const allNovels = await db
    .select({
      id: novels.id,
      title: novels.title,
      slug: novels.slug,
      status: novels.status,
      genre: novels.genre,
      views: novels.views,
      coverUrl: novels.coverUrl,
      createdAt: novels.createdAt,
      authorName: users.name,
      authorUsername: users.username,
      chapterCount: sql<number>`count(distinct ${chapters.id})::int`,
    })
    .from(novels)
    .leftJoin(users, eq(novels.authorId, users.id))
    .leftJoin(chapters, and(eq(chapters.novelId, novels.id), eq(chapters.isDraft, false)))
    .groupBy(novels.id, users.name, users.username)
    .orderBy(desc(novels.createdAt))

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <AdminNovelsClient novels={allNovels} />
    </div>
  )
}
