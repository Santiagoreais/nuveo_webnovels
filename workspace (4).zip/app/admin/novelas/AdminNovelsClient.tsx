'use client'

import { useState } from 'react'
import Link from 'next/link'
import { BookOpen, ChevronLeft, Search, Eye, Trash2, Loader2, ExternalLink } from 'lucide-react'
import { formatDate, formatNumber, GENRE_LABELS, STATUS_LABELS, STATUS_COLORS, cn } from '@/lib/utils'

type Novel = {
  id: number; title: string; slug: string; status: string; genre: string
  views: number; coverUrl: string | null; createdAt: Date | string
  authorName: string | null; authorUsername: string | null; chapterCount: number
}

export default function AdminNovelsClient({ novels: initialNovels }: { novels: Novel[] }) {
  const [novels, setNovels] = useState<Novel[]>(initialNovels)
  const [search, setSearch] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [deletingId, setDeletingId] = useState<number | null>(null)

  async function deleteNovel(id: number, title: string) {
    if (!confirm(`Remover permanentemente "${title}"? Esta ação não pode ser desfeita.`)) return
    setDeletingId(id)
    try {
      const res = await fetch(`/api/admin/novels/${id}`, { method: 'DELETE' })
      if (res.ok) setNovels(p => p.filter(n => n.id !== id))
    } finally {
      setDeletingId(null)
    }
  }

  const filtered = novels.filter(n => {
    const matchSearch = !search ||
      n.title.toLowerCase().includes(search.toLowerCase()) ||
      (n.authorName ?? '').toLowerCase().includes(search.toLowerCase())
    const matchStatus = filterStatus === 'all' || n.status === filterStatus
    return matchSearch && matchStatus
  })

  const statusCounts = novels.reduce((acc, n) => {
    acc[n.status] = (acc[n.status] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div className="flex items-center gap-3 mb-8">
        <Link href="/admin" className="p-2 rounded-lg hover:bg-accent transition-colors text-muted-foreground">
          <ChevronLeft className="h-5 w-5" />
        </Link>
        <div className="p-2.5 rounded-xl bg-primary/10 border border-primary/20">
          <BookOpen className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Gerenciar Novelas</h1>
          <p className="text-sm text-muted-foreground">{novels.length} novelas publicadas</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Buscar por título ou autor..."
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-input bg-card text-sm outline-none focus:ring-2 focus:ring-primary/50 placeholder:text-muted-foreground" />
        </div>
        <div className="flex gap-1 p-1 rounded-lg bg-card border border-border flex-wrap">
          {(['all', 'active', 'completed', 'hiatus', 'cancelled'] as const).map(s => (
            <button key={s} onClick={() => setFilterStatus(s)}
              className={cn('px-3 py-1.5 rounded-md text-xs font-medium transition-colors',
                filterStatus === s ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent')}>
              {s === 'all' ? `Todos (${novels.length})` : `${STATUS_LABELS[s]} (${statusCounts[s] ?? 0})`}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/20">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground">Novel</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Autor</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground">Status</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Caps.</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Views</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Publicada</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map(n => (
                <tr key={n.id} className="hover:bg-accent/20 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-12 rounded flex-shrink-0 bg-primary/10 overflow-hidden">
                        {n.coverUrl
                          ? <img src={n.coverUrl} alt={n.title} className="w-full h-full object-cover" />
                          : <div className="w-full h-full cover-gradient" />}
                      </div>
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate max-w-[200px]">{n.title}</p>
                        <p className="text-xs text-muted-foreground">{GENRE_LABELS[n.genre] ?? n.genre}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    {n.authorUsername && (
                      <Link href={`/perfil/${n.authorUsername}`} className="text-xs text-primary hover:underline">
                        {n.authorName}
                      </Link>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span className={cn('text-[10px] font-semibold px-1.5 py-0.5 rounded', STATUS_COLORS[n.status])}>
                      {STATUS_LABELS[n.status]}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground hidden sm:table-cell">{n.chapterCount}</td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Eye className="h-3 w-3" />{formatNumber(n.views)}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground hidden lg:table-cell">{formatDate(n.createdAt)}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <Link href={`/historias/${n.slug}`} target="_blank"
                        className="p-1.5 rounded-md text-muted-foreground hover:text-primary hover:bg-accent transition-colors">
                        <ExternalLink className="h-3.5 w-3.5" />
                      </Link>
                      <button onClick={() => deleteNovel(n.id, n.title)} disabled={deletingId === n.id}
                        className="p-1.5 rounded-md text-muted-foreground hover:text-red-400 hover:bg-red-400/10 transition-colors disabled:opacity-50">
                        {deletingId === n.id
                          ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          : <Trash2 className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground text-sm">
            Nenhuma novel encontrada.
          </div>
        )}
      </div>
    </div>
  )
}
