'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Users, BookOpen, MessageCircle, Flame, FileText, Shield, ChevronRight, Loader2, Check } from 'lucide-react'
import { formatNumber, formatDate } from '@/lib/utils'
import { useRouter } from 'next/navigation'

type User = { id: number; name: string; username: string; email: string; role: string; createdAt: Date | string }

type Stats = { users: number; novels: number; chapters: number; comments: number; hypes: number }

const ROLE_COLORS: Record<string, string> = {
  admin: 'text-red-400 bg-red-400/10',
  author: 'text-purple-400 bg-purple-400/10',
  reader: 'text-blue-400 bg-blue-400/10',
}

export default function AdminDashboard({ stats, recentUsers }: { stats: Stats; recentUsers: User[] }) {
  const router = useRouter()
  const [users, setUsers] = useState<User[]>(recentUsers)
  const [updatingId, setUpdatingId] = useState<number | null>(null)

  async function updateRole(userId: number, role: string) {
    setUpdatingId(userId)
    try {
      const res = await fetch('/api/admin/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, role }),
      })
      if (res.ok) {
        setUsers(p => p.map(u => u.id === userId ? { ...u, role } : u))
      }
    } finally {
      setUpdatingId(null)
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      {/* Header */}
      <div className="flex items-center gap-3 mb-8">
        <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/20">
          <Shield className="h-6 w-6 text-red-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">Painel Administrativo</h1>
          <p className="text-muted-foreground text-sm">Gerencie a plataforma Nuveo</p>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-10">
        {[
          { icon: <Users className="h-5 w-5 text-blue-400" />, label: 'Usuários', value: stats.users, href: '/admin/usuarios' },
          { icon: <BookOpen className="h-5 w-5 text-primary" />, label: 'Novelas', value: stats.novels, href: '/admin/novelas' },
          { icon: <FileText className="h-5 w-5 text-emerald-400" />, label: 'Capítulos', value: stats.chapters, href: null },
          { icon: <MessageCircle className="h-5 w-5 text-yellow-400" />, label: 'Comentários', value: stats.comments, href: '/admin/comentarios' },
          { icon: <Flame className="h-5 w-5 text-amber-400" />, label: 'Total Hypes', value: stats.hypes, href: null },
        ].map(s => (
          <div key={s.label} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="p-2 rounded-lg bg-background">{s.icon}</div>
              {s.href && <Link href={s.href} className="text-muted-foreground hover:text-primary transition-colors"><ChevronRight className="h-4 w-4" /></Link>}
            </div>
            <p className="text-2xl font-bold">{formatNumber(s.value)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
        {[
          { href: '/admin/usuarios', icon: <Users className="h-5 w-5" />, title: 'Gerenciar Usuários', desc: 'Promover autores, banir usuários' },
          { href: '/admin/novelas', icon: <BookOpen className="h-5 w-5" />, title: 'Moderar Novelas', desc: 'Revisar e remover conteúdo' },
          { href: '/admin/comentarios', icon: <MessageCircle className="h-5 w-5" />, title: 'Moderar Comentários', desc: 'Remover comentários impróprios' },
        ].map(l => (
          <Link key={l.href} href={l.href} className="flex items-center gap-4 p-5 rounded-xl border border-border bg-card hover:border-primary/40 hover:bg-accent/30 transition-all group">
            <div className="p-3 rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20 transition-colors">{l.icon}</div>
            <div>
              <p className="font-semibold text-sm">{l.title}</p>
              <p className="text-xs text-muted-foreground">{l.desc}</p>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground ml-auto group-hover:text-primary transition-colors" />
          </Link>
        ))}
      </div>

      {/* Recent users */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-lg">Usuários Recentes</h2>
          <Link href="/admin/usuarios" className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-1">
            Ver todos <ChevronRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="rounded-xl border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Usuário</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Email</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Cargo</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Membro desde</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-accent/20 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                          <span className="text-xs font-bold text-primary">{u.name[0].toUpperCase()}</span>
                        </div>
                        <div>
                          <p className="font-medium">{u.name}</p>
                          <p className="text-xs text-muted-foreground">@{u.username}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${ROLE_COLORS[u.role] ?? 'text-muted-foreground bg-muted'}`}>
                        {u.role === 'admin' ? 'Admin' : u.role === 'author' ? 'Autor' : 'Leitor'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{formatDate(u.createdAt)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        {u.role !== 'admin' && (
                          <>
                            {u.role === 'reader' && (
                              <button
                                onClick={() => updateRole(u.id, 'author')}
                                disabled={updatingId === u.id}
                                className="flex items-center gap-1 px-2.5 py-1 rounded text-xs bg-purple-400/10 text-purple-400 hover:bg-purple-400/20 transition-colors disabled:opacity-50"
                              >
                                {updatingId === u.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                                Promover a Autor
                              </button>
                            )}
                            {u.role === 'author' && (
                              <button
                                onClick={() => updateRole(u.id, 'reader')}
                                disabled={updatingId === u.id}
                                className="flex items-center gap-1 px-2.5 py-1 rounded text-xs bg-red-400/10 text-red-400 hover:bg-red-400/20 transition-colors disabled:opacity-50"
                              >
                                {updatingId === u.id ? <Loader2 className="h-3 w-3 animate-spin" /> : null}
                                Revogar Autor
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
