'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Shield, Users, Search, ChevronLeft, Loader2, BookOpen, Trash2 } from 'lucide-react'
import { formatDate, formatNumber } from '@/lib/utils'
import { cn } from '@/lib/utils'

type User = {
  id: number; name: string; username: string; email: string
  role: string; avatarUrl: string | null; createdAt: Date | string; novelCount: number
}

const ROLE_COLORS: Record<string, string> = {
  admin: 'text-red-400 bg-red-400/10 border-red-400/20',
  author: 'text-purple-400 bg-purple-400/10 border-purple-400/20',
  reader: 'text-blue-400 bg-blue-400/10 border-blue-400/20',
}
const ROLE_LABELS: Record<string, string> = { admin: 'Admin', author: 'Autor', reader: 'Leitor' }

export default function AdminUsersClient({
  users: initialUsers,
  currentUserId,
}: { users: User[]; currentUserId: number }) {
  const [users, setUsers] = useState<User[]>(initialUsers)
  const [search, setSearch] = useState('')
  const [filterRole, setFilterRole] = useState('all')
  const [updatingId, setUpdatingId] = useState<number | null>(null)

  async function updateRole(userId: number, role: string) {
    setUpdatingId(userId)
    try {
      const res = await fetch('/api/admin/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, role }),
      })
      if (res.ok) setUsers(p => p.map(u => u.id === userId ? { ...u, role } : u))
    } finally {
      setUpdatingId(null)
    }
  }

  const filtered = users.filter(u => {
    const matchSearch = !search ||
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.username.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase())
    const matchRole = filterRole === 'all' || u.role === filterRole
    return matchSearch && matchRole
  })

  const counts = { all: users.length, admin: 0, author: 0, reader: 0 }
  users.forEach(u => { counts[u.role as keyof typeof counts] = (counts[u.role as keyof typeof counts] || 0) + 1 })

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div className="flex items-center gap-3 mb-8">
        <Link href="/admin" className="p-2 rounded-lg hover:bg-accent transition-colors text-muted-foreground">
          <ChevronLeft className="h-5 w-5" />
        </Link>
        <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20">
          <Users className="h-5 w-5 text-blue-400" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Gerenciar Usuários</h1>
          <p className="text-sm text-muted-foreground">{users.length} usuários cadastrados</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Buscar por nome, username ou email..."
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-input bg-card text-sm outline-none focus:ring-2 focus:ring-primary/50 placeholder:text-muted-foreground"
          />
        </div>
        <div className="flex gap-1 p-1 rounded-lg bg-card border border-border">
          {(['all', 'admin', 'author', 'reader'] as const).map(r => (
            <button key={r} onClick={() => setFilterRole(r)}
              className={cn('px-3 py-1.5 rounded-md text-xs font-medium transition-colors',
                filterRole === r ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent')}>
              {r === 'all' ? 'Todos' : ROLE_LABELS[r]} ({counts[r] ?? 0})
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/20">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground">Usuário</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Email</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground">Cargo</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Novelas</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Membro desde</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map(u => (
                <tr key={u.id} className="hover:bg-accent/20 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 overflow-hidden">
                        {u.avatarUrl
                          ? <img src={u.avatarUrl} alt={u.name} className="h-full w-full object-cover" />
                          : <span className="text-sm font-bold text-primary">{u.name[0].toUpperCase()}</span>}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{u.name}</p>
                        <p className="text-xs text-muted-foreground">@{u.username}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground hidden md:table-cell text-xs">{u.email}</td>
                  <td className="px-4 py-3">
                    <span className={cn('text-xs font-semibold px-2 py-0.5 rounded-full border', ROLE_COLORS[u.role] ?? '')}>
                      {ROLE_LABELS[u.role] ?? u.role}
                    </span>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <BookOpen className="h-3 w-3" />{u.novelCount}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground hidden lg:table-cell">{formatDate(u.createdAt)}</td>
                  <td className="px-4 py-3">
                    {u.id === currentUserId ? (
                      <span className="text-xs text-muted-foreground italic">você</span>
                    ) : (
                      <div className="flex items-center gap-1 flex-wrap">
                        {updatingId === u.id
                          ? <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />
                          : u.role === 'reader'
                          ? <button onClick={() => updateRole(u.id, 'author')}
                              className="px-2.5 py-1 rounded text-xs bg-purple-400/10 text-purple-400 hover:bg-purple-400/20 border border-purple-400/20 transition-colors">
                              → Autor
                            </button>
                          : u.role === 'author'
                          ? <>
                              <button onClick={() => updateRole(u.id, 'reader')}
                                className="px-2.5 py-1 rounded text-xs bg-muted text-muted-foreground hover:bg-accent border border-border transition-colors">
                                → Leitor
                              </button>
                              <button onClick={() => updateRole(u.id, 'admin')}
                                className="px-2.5 py-1 rounded text-xs bg-red-400/10 text-red-400 hover:bg-red-400/20 border border-red-400/20 transition-colors">
                                → Admin
                              </button>
                            </>
                          : u.role === 'admin'
                          ? <button onClick={() => updateRole(u.id, 'author')}
                              className="px-2.5 py-1 rounded text-xs bg-muted text-muted-foreground hover:bg-accent border border-border transition-colors">
                              → Autor
                            </button>
                          : null
                        }
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground text-sm">
            Nenhum usuário encontrado.
          </div>
        )}
      </div>
    </div>
  )
}
