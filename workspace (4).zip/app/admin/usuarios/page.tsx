export const dynamic = 'force-dynamic'
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import AdminUsersClient from './AdminUsersClient'
import { db } from '@/db'
import { users, novels } from '@/db/schema'
import { sql } from 'drizzle-orm'
import { eq, desc } from 'drizzle-orm'

export default async function AdminUsuariosPage() {
  const user = await getSession()
  if (!user || user.role !== 'admin') redirect('/')

  const allUsers = await db
    .select({
      id: users.id,
      name: users.name,
      username: users.username,
      email: users.email,
      role: users.role,
      avatarUrl: users.avatarUrl,
      createdAt: users.createdAt,
      novelCount: sql<number>`count(distinct ${novels.id})::int`,
    })
    .from(users)
    .leftJoin(novels, eq(novels.authorId, users.id))
    .groupBy(users.id)
    .orderBy(desc(users.createdAt))

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <AdminUsersClient users={allUsers} currentUserId={user.id} />
    </div>
  )
}
