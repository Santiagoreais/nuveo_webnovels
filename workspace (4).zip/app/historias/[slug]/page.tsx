export const dynamic = 'force-dynamic'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import NovelDetailClient from './NovelDetailClient'
import { db } from '@/db'
import { novels, users, chapters, votes, hypes, comments, bookmarks } from '@/db/schema'
import { eq, and, asc, sql, isNull } from 'drizzle-orm'
import { GENRE_LABELS, STATUS_LABELS, STATUS_COLORS, formatNumber, formatDate } from '@/lib/utils'
import { Eye, Star, Flame, BookOpen, Clock, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'

export default async function NovelPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const user = await getSession()

  const [novelRow] = await db.select({
    id: novels.id,
    title: novels.title,
    slug: novels.slug,
    description: novels.description,
    coverUrl: novels.coverUrl,
    genre: novels.genre,
    tags: novels.tags,
    status: novels.status,
    views: novels.views,
    wordCount: novels.wordCount,
    publishedAt: novels.publishedAt,
    createdAt: novels.createdAt,
    authorId: novels.authorId,
    authorName: users.name,
    authorUsername: users.username,
    authorBio: users.bio,
    authorAvatar: users.avatarUrl,
    avgRating: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
    totalVotes: sql<number>`count(distinct ${votes.id})::int`,
    hypeCount: sql<number>`count(distinct ${hypes.id})::int`,
  })
    .from(novels)
    .leftJoin(users, eq(novels.authorId, users.id))
    .leftJoin(votes, eq(votes.novelId, novels.id))
    .leftJoin(hypes, eq(hypes.novelId, novels.id))
    .where(eq(novels.slug, slug))
    .groupBy(novels.id, users.name, users.username, users.bio, users.avatarUrl)
    .limit(1)

  if (!novelRow) notFound()

  // Increment views
  await db.update(novels).set({ views: sql`${novels.views} + 1` }).where(eq(novels.id, novelRow.id))

  const chapterList = await db.select({
    id: chapters.id,
    number: chapters.number,
    title: chapters.title,
    wordCount: chapters.wordCount,
    views: chapters.views,
    publishedAt: chapters.publishedAt,
  })
    .from(chapters)
    .where(and(eq(chapters.novelId, novelRow.id), eq(chapters.isDraft, false)))
    .orderBy(asc(chapters.number))

  const novelComments = await db.select({
    id: comments.id,
    content: comments.content,
    parentId: comments.parentId,
    createdAt: comments.createdAt,
    userId: comments.userId,
    userName: users.name,
    userUsername: users.username,
    userAvatar: users.avatarUrl,
  })
    .from(comments)
    .leftJoin(users, eq(comments.userId, users.id))
    .where(and(eq(comments.novelId, novelRow.id), eq(comments.isDeleted, false), isNull(comments.chapterId)))
    .orderBy(asc(comments.createdAt))

  let userVote = null
  let userHypedToday = false
  let isBookmarked = false

  if (user) {
    const today = new Date().toISOString().slice(0, 10)
    const [uv] = await db.select({ value: votes.value }).from(votes)
      .where(and(eq(votes.userId, user.id), eq(votes.novelId, novelRow.id))).limit(1)
    userVote = uv?.value ?? null

    const [uh] = await db.select({ id: hypes.id }).from(hypes)
      .where(and(eq(hypes.userId, user.id), eq(hypes.novelId, novelRow.id), eq(hypes.hypeDate, today))).limit(1)
    userHypedToday = !!uh

    const [bm] = await db.select({ id: bookmarks.id }).from(bookmarks)
      .where(and(eq(bookmarks.userId, user.id), eq(bookmarks.novelId, novelRow.id))).limit(1)
    isBookmarked = !!bm
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <div className="mx-auto max-w-7xl px-4 py-8">

        {/* Breadcrumb */}
        <nav className="flex items-center gap-1 text-sm text-muted-foreground mb-6">
          <Link href="/" className="hover:text-primary transition-colors">Início</Link>
          <ChevronRight className="h-3.5 w-3.5" />
          <Link href="/historias" className="hover:text-primary transition-colors">Histórias</Link>
          <ChevronRight className="h-3.5 w-3.5" />
          <span className="text-foreground/70 truncate max-w-xs">{novelRow.title}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Left: Cover + actions */}
          <div className="lg:col-span-1">
            <div className="sticky top-20 space-y-4">
              {/* Cover */}
              <div className="aspect-[3/4] rounded-xl overflow-hidden bg-primary/10 shadow-2xl shadow-black/40">
                {novelRow.coverUrl ? (
                  <img src={novelRow.coverUrl} alt={novelRow.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full cover-gradient flex items-center justify-center">
                    <BookOpen className="h-16 w-16 text-primary/30" />
                  </div>
                )}
              </div>

              {/* Hype + Vote via client */}
              <NovelDetailClient
                slug={slug}
                novelId={novelRow.id}
                user={user ? { id: user.id, name: user.name, username: user.username, role: user.role, avatarUrl: user.avatarUrl } : null}
                initialHype={novelRow.hypeCount}
                initialHypedToday={userHypedToday}
                initialAvgRating={novelRow.avgRating}
                initialTotalVotes={novelRow.totalVotes}
                initialUserVote={userVote}
                initialIsBookmarked={isBookmarked}
                novelComments={novelComments}
              />
            </div>
          </div>

          {/* Right: Info + Chapters */}
          <div className="lg:col-span-3 space-y-6">
            {/* Title + Meta */}
            <div>
              <div className="flex items-start justify-between gap-4 mb-3">
                <h1 className="text-3xl font-bold leading-tight">{novelRow.title}</h1>
                <span className={cn('flex-shrink-0 text-xs font-semibold px-2.5 py-1 rounded-full', STATUS_COLORS[novelRow.status])}>
                  {STATUS_LABELS[novelRow.status]}
                </span>
              </div>
              <p className="text-muted-foreground">
                por{' '}
                <Link href={`/perfil/${novelRow.authorUsername}`} className="text-primary hover:underline font-medium">
                  {novelRow.authorName}
                </Link>
              </p>

              {/* Stats row */}
              <div className="flex flex-wrap items-center gap-4 mt-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <Eye className="h-4 w-4" /> {formatNumber(novelRow.views)} leituras
                </span>
                <span className="flex items-center gap-1.5">
                  <Star className="h-4 w-4 fill-gold text-gold" />
                  {novelRow.avgRating > 0 ? novelRow.avgRating.toFixed(1) : '–'}
                  <span className="text-xs">({novelRow.totalVotes} votos)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <Flame className="h-4 w-4 text-amber-400" /> {formatNumber(novelRow.hypeCount)} hype
                </span>
                <span className="flex items-center gap-1.5">
                  <BookOpen className="h-4 w-4" /> {chapterList.length} capítulos
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock className="h-4 w-4" /> {novelRow.publishedAt ? formatDate(novelRow.publishedAt) : '–'}
                </span>
              </div>

              {/* Genre + tags */}
              <div className="flex flex-wrap gap-2 mt-4">
                <span className="text-xs px-2.5 py-1 rounded-full bg-primary/15 text-primary font-medium">
                  {GENRE_LABELS[novelRow.genre] ?? novelRow.genre}
                </span>
                {novelRow.tags?.split(',').filter(Boolean).map(tag => (
                  <span key={tag.trim()} className="text-xs px-2.5 py-1 rounded-full bg-accent text-muted-foreground">{tag.trim()}</span>
                ))}
              </div>
            </div>

            {/* Description */}
            <div className="rounded-xl border border-border bg-card p-5">
              <h2 className="font-semibold mb-3">Sinopse</h2>
              <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">{novelRow.description}</p>
            </div>

            {/* Chapters */}
            <div className="rounded-xl border border-border bg-card overflow-hidden">
              <div className="px-5 py-4 border-b border-border flex items-center justify-between">
                <h2 className="font-semibold">Capítulos ({chapterList.length})</h2>
                {chapterList.length > 0 && (
                  <Link href={`/historias/${slug}/1`}
                    className="text-sm px-4 py-1.5 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-colors">
                    Ler do início
                  </Link>
                )}
              </div>
              {chapterList.length === 0 ? (
                <div className="px-5 py-8 text-center text-muted-foreground text-sm">Nenhum capítulo publicado ainda.</div>
              ) : (
                <div className="divide-y divide-border max-h-[400px] overflow-y-auto">
                  {chapterList.map(ch => (
                    <Link key={ch.id} href={`/historias/${slug}/${ch.number}`}
                      className="flex items-center justify-between px-5 py-3 hover:bg-accent/50 transition-colors group">
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="text-xs text-muted-foreground w-8 flex-shrink-0">#{ch.number}</span>
                        <span className="text-sm font-medium group-hover:text-primary transition-colors truncate">{ch.title}</span>
                      </div>
                      <div className="flex items-center gap-3 flex-shrink-0 text-xs text-muted-foreground">
                        <span>{ch.wordCount.toLocaleString()} palavras</span>
                        <span>{ch.publishedAt ? formatDate(ch.publishedAt) : ''}</span>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
