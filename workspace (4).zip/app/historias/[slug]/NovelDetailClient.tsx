'use client'

import { useState } from 'react'
import { Flame, Star, Bookmark, BookmarkCheck, MessageCircle, Send, Reply, Loader2 } from 'lucide-react'
import { formatDate, formatNumber } from '@/lib/utils'

type User = { id: number; name: string; username: string; role: string; avatarUrl: string | null } | null

type Comment = {
  id: number
  content: string
  parentId: number | null
  createdAt: Date | string
  userId: number
  userName: string | null
  userUsername: string | null
  userAvatar: string | null
}

type Props = {
  slug: string
  novelId: number
  user: User
  initialHype: number
  initialHypedToday: boolean
  initialAvgRating: number
  initialTotalVotes: number
  initialUserVote: number | null
  initialIsBookmarked: boolean
  novelComments: Comment[]
}

export default function NovelDetailClient({
  slug, novelId, user,
  initialHype, initialHypedToday,
  initialAvgRating, initialTotalVotes, initialUserVote,
  initialIsBookmarked, novelComments,
}: Props) {
  const [hypeCount, setHypeCount] = useState(initialHype)
  const [hypedToday, setHypedToday] = useState(initialHypedToday)
  const [hypeLoading, setHypeLoading] = useState(false)
  const [avgRating, setAvgRating] = useState(initialAvgRating)
  const [totalVotes, setTotalVotes] = useState(initialTotalVotes)
  const [userVote, setUserVote] = useState(initialUserVote)
  const [hoverStar, setHoverStar] = useState(0)
  const [isBookmarked, setIsBookmarked] = useState(initialIsBookmarked)
  const [comments, setComments] = useState<Comment[]>(novelComments)
  const [commentText, setCommentText] = useState('')
  const [replyTo, setReplyTo] = useState<number | null>(null)
  const [replyText, setReplyText] = useState('')
  const [commentLoading, setCommentLoading] = useState(false)

  async function handleHype() {
    if (!user) { window.location.href = '/login'; return }
    if (hypedToday || hypeLoading) return
    setHypeLoading(true)
    try {
      const res = await fetch(`/api/novels/${slug}/hype`, { method: 'POST' })
      if (res.ok) {
        const data = await res.json()
        setHypeCount(data.hypeCount)
        setHypedToday(true)
      }
    } finally {
      setHypeLoading(false)
    }
  }

  async function handleVote(value: number) {
    if (!user) { window.location.href = '/login'; return }
    const res = await fetch(`/api/novels/${slug}/vote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ value }),
    })
    if (res.ok) {
      const data = await res.json()
      setAvgRating(data.avgRating)
      setTotalVotes(data.totalVotes)
      setUserVote(value)
    }
  }

  async function handleBookmark() {
    if (!user) { window.location.href = '/login'; return }
    const method = isBookmarked ? 'DELETE' : 'POST'
    const res = await fetch(`/api/bookmarks`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ novelId }),
    })
    if (res.ok) setIsBookmarked(p => !p)
  }

  async function submitComment(parentId?: number) {
    if (!user) { window.location.href = '/login'; return }
    const text = parentId ? replyText : commentText
    if (!text.trim()) return
    setCommentLoading(true)
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ novelSlug: slug, content: text.trim(), parentId }),
      })
      if (res.ok) {
        const data = await res.json()
        setComments(p => [...p, data.comment])
        if (parentId) { setReplyTo(null); setReplyText('') }
        else setCommentText('')
      }
    } finally {
      setCommentLoading(false)
    }
  }

  const topComments = comments.filter(c => !c.parentId)
  const replies = (parentId: number) => comments.filter(c => c.parentId === parentId)

  return (
    <div className="space-y-4">
      {/* Hype button */}
      <button
        onClick={handleHype}
        disabled={hypeLoading || hypedToday}
        className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm transition-all ${
          hypedToday
            ? 'bg-amber-500/20 border border-amber-500/40 text-amber-400 cursor-default'
            : 'bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20 hover:hype-glow active:scale-95'
        }`}
      >
        {hypeLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Flame className="h-5 w-5" />}
        {hypedToday ? `Você deu Hype! (${formatNumber(hypeCount)})` : `Dar Hype · ${formatNumber(hypeCount)}`}
      </button>

      {/* Bookmark */}
      <button
        onClick={handleBookmark}
        className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium border transition-all ${
          isBookmarked
            ? 'bg-primary/15 border-primary/30 text-primary'
            : 'border-border text-muted-foreground hover:bg-accent hover:text-foreground'
        }`}
      >
        {isBookmarked ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
        {isBookmarked ? 'Na Biblioteca' : 'Adicionar à Biblioteca'}
      </button>

      {/* Rating */}
      <div className="rounded-xl border border-border bg-card p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-medium">Avaliação</span>
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-gold text-gold" />
            <span className="font-bold">{avgRating > 0 ? avgRating.toFixed(1) : '–'}</span>
            <span className="text-xs text-muted-foreground">({totalVotes})</span>
          </div>
        </div>
        <div className="flex items-center gap-1 justify-center">
          {[1, 2, 3, 4, 5].map(s => (
            <button
              key={s}
              onMouseEnter={() => setHoverStar(s)}
              onMouseLeave={() => setHoverStar(0)}
              onClick={() => handleVote(s)}
              className="transition-transform hover:scale-110"
            >
              <Star className={`h-6 w-6 transition-colors ${
                s <= (hoverStar || userVote || 0)
                  ? 'fill-gold text-gold'
                  : 'text-muted-foreground'
              }`} />
            </button>
          ))}
        </div>
        {userVote && <p className="text-xs text-center text-muted-foreground mt-2">Sua nota: {userVote}/5</p>}
      </div>

      {/* Comments section */}
      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="font-semibold flex items-center gap-2 mb-4">
          <MessageCircle className="h-4 w-4" />
          Comentários ({comments.length})
        </h3>

        {/* Add comment */}
        {user ? (
          <div className="mb-4">
            <textarea
              value={commentText}
              onChange={e => setCommentText(e.target.value)}
              placeholder="Deixe um comentário..."
              rows={3}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/50 resize-none placeholder:text-muted-foreground transition-all"
            />
            <button
              onClick={() => submitComment()}
              disabled={commentLoading || !commentText.trim()}
              className="mt-2 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:bg-primary/90 disabled:opacity-50 transition-colors"
            >
              {commentLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Send className="h-3 w-3" />}
              Comentar
            </button>
          </div>
        ) : (
          <p className="text-xs text-muted-foreground mb-4">
            <a href="/login" className="text-primary hover:underline">Entre</a> para comentar
          </p>
        )}

        {/* Comments list */}
        <div className="space-y-4 max-h-96 overflow-y-auto">
          {topComments.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-4">Sem comentários ainda. Seja o primeiro!</p>
          ) : (
            topComments.map(c => (
              <div key={c.id} className="space-y-2">
                <div className="flex items-start gap-2.5">
                  <div className="h-7 w-7 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {c.userAvatar ? (
                      <img src={c.userAvatar} alt={c.userName ?? ''} className="h-full w-full object-cover" />
                    ) : (
                      <span className="text-xs font-semibold text-primary">{(c.userName ?? 'U')[0].toUpperCase()}</span>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-semibold">{c.userName}</span>
                      <span className="text-xs text-muted-foreground">{formatDate(c.createdAt)}</span>
                    </div>
                    <p className="text-sm text-foreground/90 leading-relaxed">{c.content}</p>
                    {user && (
                      <button onClick={() => setReplyTo(replyTo === c.id ? null : c.id)} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary mt-1 transition-colors">
                        <Reply className="h-3 w-3" /> Responder
                      </button>
                    )}
                  </div>
                </div>

                {/* Replies */}
                {replies(c.id).length > 0 && (
                  <div className="ml-9 space-y-2 border-l-2 border-border pl-3">
                    {replies(c.id).map(r => (
                      <div key={r.id} className="flex items-start gap-2">
                        <div className="h-6 w-6 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0">
                          <span className="text-xs font-semibold text-primary">{(r.userName ?? 'U')[0].toUpperCase()}</span>
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="text-xs font-semibold">{r.userName}</span>
                            <span className="text-xs text-muted-foreground">{formatDate(r.createdAt)}</span>
                          </div>
                          <p className="text-sm text-foreground/90">{r.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Reply box */}
                {replyTo === c.id && (
                  <div className="ml-9">
                    <textarea
                      value={replyText}
                      onChange={e => setReplyText(e.target.value)}
                      placeholder="Escreva uma resposta..."
                      rows={2}
                      className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/50 resize-none placeholder:text-muted-foreground"
                    />
                    <div className="flex gap-2 mt-1">
                      <button onClick={() => submitComment(c.id)} disabled={commentLoading || !replyText.trim()} className="flex items-center gap-1 px-2.5 py-1 rounded bg-primary text-primary-foreground text-xs font-medium hover:bg-primary/90 disabled:opacity-50">
                        <Send className="h-3 w-3" /> Responder
                      </button>
                      <button onClick={() => setReplyTo(null)} className="px-2.5 py-1 rounded text-xs text-muted-foreground hover:bg-accent">Cancelar</button>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
