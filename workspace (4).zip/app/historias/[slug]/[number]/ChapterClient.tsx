'use client'

import { useState } from 'react'
import { MessageCircle, Send, Reply, Loader2 } from 'lucide-react'
import { formatDate } from '@/lib/utils'

type User = { id: number; name: string; username: string; role: string; avatarUrl: string | null } | null

type Comment = {
  id: number
  content: string
  parentId: number | null
  createdAt: Date | string
  userId: number
  userName: string | null
  userUsername: string | null
  userAvatar: string | null
}

export default function ChapterClient({
  slug, chapterId, user, initialComments,
}: {
  slug: string
  chapterId: number
  user: User
  initialComments: Comment[]
}) {
  const [comments, setComments] = useState<Comment[]>(initialComments)
  const [commentText, setCommentText] = useState('')
  const [replyTo, setReplyTo] = useState<number | null>(null)
  const [replyText, setReplyText] = useState('')
  const [loading, setLoading] = useState(false)

  async function submitComment(parentId?: number) {
    if (!user) { window.location.href = '/login'; return }
    const text = parentId ? replyText : commentText
    if (!text.trim()) return
    setLoading(true)
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ novelSlug: slug, chapterId, content: text.trim(), parentId }),
      })
      if (res.ok) {
        const data = await res.json()
        setComments(p => [...p, data.comment])
        if (parentId) { setReplyTo(null); setReplyText('') }
        else setCommentText('')
      }
    } finally {
      setLoading(false)
    }
  }

  const topComments = comments.filter(c => !c.parentId)
  const replies = (parentId: number) => comments.filter(c => c.parentId === parentId)

  return (
    <div className="mt-12 pt-8 border-t border-border">
      <h3 className="font-semibold text-lg flex items-center gap-2 mb-6">
        <MessageCircle className="h-5 w-5 text-primary" />
        Comentários do Capítulo ({comments.length})
      </h3>

      {user ? (
        <div className="mb-6">
          <textarea
            value={commentText}
            onChange={e => setCommentText(e.target.value)}
            placeholder="O que você achou deste capítulo?"
            rows={3}
            className="w-full rounded-lg border border-input bg-card px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/50 resize-none placeholder:text-muted-foreground transition-all"
          />
          <button
            onClick={() => submitComment()}
            disabled={loading || !commentText.trim()}
            className="mt-2 flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50 transition-colors"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            Comentar
          </button>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground mb-6">
          <a href="/login" className="text-primary hover:underline font-medium">Entre</a> para comentar neste capítulo
        </p>
      )}

      <div className="space-y-5">
        {topComments.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8 border border-dashed border-border rounded-xl">
            Nenhum comentário ainda. Seja o primeiro a comentar!
          </p>
        ) : (
          topComments.map(c => (
            <div key={c.id} className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {c.userAvatar ? (
                    <img src={c.userAvatar} alt={c.userName ?? ''} className="h-full w-full object-cover" />
                  ) : (
                    <span className="text-sm font-bold text-primary">{(c.userName ?? 'U')[0].toUpperCase()}</span>
                  )}
                </div>
                <div className="flex-1 rounded-xl bg-card border border-border p-3">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-sm font-semibold">{c.userName}</span>
                    <span className="text-xs text-muted-foreground">{formatDate(c.createdAt)}</span>
                  </div>
                  <p className="text-sm text-foreground/90 leading-relaxed">{c.content}</p>
                  {user && (
                    <button onClick={() => setReplyTo(replyTo === c.id ? null : c.id)} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary mt-2 transition-colors">
                      <Reply className="h-3 w-3" /> Responder
                    </button>
                  )}
                </div>
              </div>

              {/* Replies */}
              {replies(c.id).length > 0 && (
                <div className="ml-11 space-y-2">
                  {replies(c.id).map(r => (
                    <div key={r.id} className="flex items-start gap-3">
                      <div className="h-7 w-7 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold text-primary">{(r.userName ?? 'U')[0].toUpperCase()}</span>
                      </div>
                      <div className="flex-1 rounded-xl bg-card/60 border border-border p-3">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs font-semibold">{r.userName}</span>
                          <span className="text-xs text-muted-foreground">{formatDate(r.createdAt)}</span>
                        </div>
                        <p className="text-sm text-foreground/90">{r.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Reply box */}
              {replyTo === c.id && (
                <div className="ml-11">
                  <textarea
                    value={replyText}
                    onChange={e => setReplyText(e.target.value)}
                    placeholder="Escreva uma resposta..."
                    rows={2}
                    className="w-full rounded-lg border border-input bg-card px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/50 resize-none placeholder:text-muted-foreground"
                  />
                  <div className="flex gap-2 mt-2">
                    <button onClick={() => submitComment(c.id)} disabled={loading || !replyText.trim()} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:bg-primary/90 disabled:opacity-50">
                      <Send className="h-3 w-3" /> Responder
                    </button>
                    <button onClick={() => setReplyTo(null)} className="px-3 py-1.5 rounded-lg text-xs text-muted-foreground hover:bg-accent transition-colors">Cancelar</button>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  )
}
