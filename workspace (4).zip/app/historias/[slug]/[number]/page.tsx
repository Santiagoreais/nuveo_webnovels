export const dynamic = 'force-dynamic'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import ChapterClient from './ChapterClient'
import { db } from '@/db'
import { novels, chapters, users, comments, votes, hypes } from '@/db/schema'
import { eq, and, asc, sql, isNull } from 'drizzle-orm'
import { ChevronLeft, ChevronRight, BookOpen, List } from 'lucide-react'
import { formatDate } from '@/lib/utils'

export default async function ChapterPage({
  params,
}: {
  params: Promise<{ slug: string; number: string }>
}) {
  const { slug, number } = await params
  const num = parseInt(number)
  if (isNaN(num)) notFound()

  const user = await getSession()

  const [novel] = await db.select({ id: novels.id, title: novels.title, slug: novels.slug, authorId: novels.authorId })
    .from(novels).where(eq(novels.slug, slug)).limit(1)
  if (!novel) notFound()

  const [chapter] = await db.select()
    .from(chapters)
    .where(and(eq(chapters.novelId, novel.id), eq(chapters.number, num), eq(chapters.isDraft, false)))
    .limit(1)
  if (!chapter) notFound()

  // Increment chapter views
  await db.update(chapters).set({ views: sql`${chapters.views} + 1` }).where(eq(chapters.id, chapter.id))

  // Prev/Next
  const allChapters = await db.select({ number: chapters.number, title: chapters.title })
    .from(chapters)
    .where(and(eq(chapters.novelId, novel.id), eq(chapters.isDraft, false)))
    .orderBy(asc(chapters.number))

  const currentIndex = allChapters.findIndex(c => c.number === num)
  const prev = currentIndex > 0 ? allChapters[currentIndex - 1] : null
  const next = currentIndex < allChapters.length - 1 ? allChapters[currentIndex + 1] : null

  // Chapter comments
  const chapterComments = await db.select({
    id: comments.id,
    content: comments.content,
    parentId: comments.parentId,
    createdAt: comments.createdAt,
    userId: comments.userId,
    userName: users.name,
    userUsername: users.username,
    userAvatar: users.avatarUrl,
  })
    .from(comments)
    .leftJoin(users, eq(comments.userId, users.id))
    .where(and(eq(comments.chapterId, chapter.id), eq(comments.isDeleted, false)))
    .orderBy(asc(comments.createdAt))

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />

      {/* Chapter header */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-16 z-40">
        <div className="mx-auto max-w-3xl px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 min-w-0">
            <Link href={`/historias/${slug}`} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors flex-shrink-0">
              <BookOpen className="h-4 w-4" />
              <span className="hidden sm:inline truncate max-w-32">{novel.title}</span>
            </Link>
            <ChevronRight className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
            <span className="text-sm font-medium truncate">Cap. {chapter.number}</span>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            {prev ? (
              <Link href={`/historias/${slug}/${prev.number}`}
                className="flex items-center gap-1 px-3 py-1.5 rounded-md text-sm border border-border hover:bg-accent transition-colors">
                <ChevronLeft className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Anterior</span>
              </Link>
            ) : <div className="w-20 hidden sm:block" />}

            <Link href={`/historias/${slug}`}
              className="p-1.5 rounded-md text-muted-foreground hover:bg-accent hover:text-foreground transition-colors">
              <List className="h-4 w-4" />
            </Link>

            {next ? (
              <Link href={`/historias/${slug}/${next.number}`}
                className="flex items-center gap-1 px-3 py-1.5 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors">
                <span className="hidden sm:inline">Próximo</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            ) : (
              <Link href={`/historias/${slug}`}
                className="flex items-center gap-1 px-3 py-1.5 rounded-md text-sm border border-border text-muted-foreground hover:bg-accent transition-colors">
                <span className="hidden sm:inline">Fim</span>
                <BookOpen className="h-3.5 w-3.5" />
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="mx-auto max-w-3xl px-4 py-10">
        {/* Chapter title */}
        <div className="mb-8 text-center">
          <p className="text-sm text-muted-foreground mb-1">Capítulo {chapter.number}</p>
          <h1 className="text-2xl sm:text-3xl font-bold">{chapter.title}</h1>
          <p className="text-xs text-muted-foreground mt-2">
            {chapter.wordCount.toLocaleString()} palavras ·{' '}
            {chapter.publishedAt ? formatDate(chapter.publishedAt) : ''}
          </p>
        </div>

        {/* Chapter body */}
        <article
          className="chapter-content prose-nuveo"
          dangerouslySetInnerHTML={{
            __html: chapter.content.startsWith('<')
              ? chapter.content
              : chapter.content.split('\n').filter(Boolean).map(p => `<p>${p}</p>`).join('')
          }}
        />

        {/* Bottom nav */}
        <div className="flex items-center justify-between gap-4 mt-12 pt-8 border-t border-border">
          {prev ? (
            <Link href={`/historias/${slug}/${prev.number}`}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border hover:bg-accent transition-colors group flex-1 max-w-xs">
              <ChevronLeft className="h-4 w-4 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground">Anterior</p>
                <p className="text-sm font-medium truncate group-hover:text-primary">{prev.title}</p>
              </div>
            </Link>
          ) : <div className="flex-1" />}

          {next ? (
            <Link href={`/historias/${slug}/${next.number}`}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-primary/10 border border-primary/30 hover:bg-primary/20 transition-colors group flex-1 max-w-xs justify-end">
              <div className="min-w-0 text-right">
                <p className="text-xs text-muted-foreground">Próximo</p>
                <p className="text-sm font-medium truncate group-hover:text-primary">{next.title}</p>
              </div>
              <ChevronRight className="h-4 w-4 flex-shrink-0" />
            </Link>
          ) : (
            <Link href={`/historias/${slug}`}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border hover:bg-accent transition-colors">
              <BookOpen className="h-4 w-4" />
              <span className="text-sm font-medium">Ver índice</span>
            </Link>
          )}
        </div>

        {/* Chapter Comments */}
        <ChapterClient
          slug={slug}
          chapterId={chapter.id}
          user={user ? { id: user.id, name: user.name, username: user.username, role: user.role, avatarUrl: user.avatarUrl } : null}
          initialComments={chapterComments}
        />
      </main>
    </div>
  )
}
