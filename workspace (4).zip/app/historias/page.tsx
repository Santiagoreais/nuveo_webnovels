export const dynamic = 'force-dynamic'
import { db } from '@/db'
import { novels, users, chapters, votes, hypes } from '@/db/schema'
import { eq, desc, ilike, and, sql } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import NovelCard, { NovelCardData } from '@/components/NovelCard'
import { Search, Filter } from 'lucide-react'
import Link from 'next/link'
import { GENRE_LABELS, STATUS_LABELS } from '@/lib/utils'

type SearchParams = { genre?: string; status?: string; q?: string; sort?: string; page?: string }

async function getNovels(params: SearchParams): Promise<NovelCardData[]> {
  const page = Math.max(1, parseInt(params.page ?? '1'))
  const limit = 24
  const offset = (page - 1) * limit

  const conditions = []
  if (params.genre) conditions.push(eq(novels.genre, params.genre as never))
  if (params.status) conditions.push(eq(novels.status, params.status as never))
  if (params.q) conditions.push(ilike(novels.title, `%${params.q}%`))
  const whereClause = conditions.length > 0 ? and(...conditions) : undefined

  const rows = await db.select({
    id: novels.id,
    title: novels.title,
    slug: novels.slug,
    description: novels.description,
    coverUrl: novels.coverUrl,
    genre: novels.genre,
    status: novels.status,
    views: novels.views,
    authorName: users.name,
    authorUsername: users.username,
    chapterCount: sql<number>`count(distinct ${chapters.id})::int`,
    avgRating: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
    totalVotes: sql<number>`count(distinct ${votes.id})::int`,
    hypeCount: sql<number>`count(distinct ${hypes.id})::int`,
  })
    .from(novels)
    .leftJoin(users, eq(novels.authorId, users.id))
    .leftJoin(chapters, and(eq(chapters.novelId, novels.id), eq(chapters.isDraft, false)))
    .leftJoin(votes, eq(votes.novelId, novels.id))
    .leftJoin(hypes, eq(hypes.novelId, novels.id))
    .where(whereClause)
    .groupBy(novels.id, users.name, users.username)
    .orderBy(
      params.sort === 'views' ? desc(novels.views) :
      params.sort === 'hype' ? desc(sql`count(distinct ${hypes.id})`) :
      params.sort === 'rating' ? desc(sql`avg(${votes.value})`) :
      desc(novels.createdAt)
    )
    .limit(limit)
    .offset(offset)

  return rows as NovelCardData[]
}

export default async function HistoriasPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>
}) {
  const params = await searchParams
  const [user, novelList] = await Promise.all([getSession(), getNovels(params)])

  const genres = Object.entries(GENRE_LABELS).slice(0, 12)
  const statuses = Object.entries(STATUS_LABELS)
  const sorts = [
    { value: 'recent', label: 'Mais Recentes' },
    { value: 'views', label: 'Mais Lidas' },
    { value: 'hype', label: 'Mais Hype' },
    { value: 'rating', label: 'Melhor Nota' },
  ]

  function buildUrl(updates: Record<string, string | undefined>) {
    const p = new URLSearchParams()
    const merged = { ...params, ...updates }
    Object.entries(merged).forEach(([k, v]) => { if (v) p.set(k, v) })
    return `/historias?${p.toString()}`
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <div className="mx-auto max-w-7xl px-4 py-8">

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Histórias</h1>
          <p className="text-muted-foreground">Explore webnovels originais em português</p>
        </div>

        {/* Search */}
        <form method="GET" action="/historias" className="mb-6">
          <div className="relative max-w-xl">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              name="q"
              defaultValue={params.q}
              placeholder="Buscar por título..."
              className="w-full rounded-lg border border-input bg-card pl-10 pr-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all placeholder:text-muted-foreground"
            />
            <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-1 rounded-md bg-primary text-primary-foreground text-xs font-medium hover:bg-primary/90 transition-colors">
              Buscar
            </button>
          </div>
        </form>

        <div className="flex gap-8">
          {/* Sidebar filters */}
          <aside className="hidden md:block w-48 flex-shrink-0">
            <div className="sticky top-20 space-y-6">
              {/* Sort */}
              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Ordenar</h3>
                <div className="space-y-1">
                  {sorts.map(s => (
                    <Link key={s.value} href={buildUrl({ sort: s.value, page: '1' })}
                      className={`block px-3 py-1.5 rounded-md text-sm transition-colors ${params.sort === s.value || (!params.sort && s.value === 'recent') ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent'}`}>
                      {s.label}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Status */}
              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Status</h3>
                <div className="space-y-1">
                  <Link href={buildUrl({ status: undefined, page: '1' })}
                    className={`block px-3 py-1.5 rounded-md text-sm transition-colors ${!params.status ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent'}`}>
                    Todos
                  </Link>
                  {statuses.map(([v, l]) => (
                    <Link key={v} href={buildUrl({ status: v, page: '1' })}
                      className={`block px-3 py-1.5 rounded-md text-sm transition-colors ${params.status === v ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent'}`}>
                      {l}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Genre */}
              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Gênero</h3>
                <div className="space-y-1">
                  <Link href={buildUrl({ genre: undefined, page: '1' })}
                    className={`block px-3 py-1.5 rounded-md text-sm transition-colors ${!params.genre ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent'}`}>
                    Todos
                  </Link>
                  {Object.entries(GENRE_LABELS).map(([v, l]) => (
                    <Link key={v} href={buildUrl({ genre: v, page: '1' })}
                      className={`block px-3 py-1.5 rounded-md text-sm transition-colors ${params.genre === v ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent'}`}>
                      {l}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* Grid */}
          <div className="flex-1">
            {novelList.length === 0 ? (
              <div className="text-center py-16 border border-dashed border-border rounded-xl">
                <p className="text-muted-foreground">Nenhuma história encontrada.</p>
                {params.q && (
                  <Link href="/historias" className="mt-3 inline-block text-primary hover:underline text-sm">Limpar filtros</Link>
                )}
              </div>
            ) : (
              <>
                <p className="text-sm text-muted-foreground mb-4">{novelList.length} resultado{novelList.length !== 1 ? 's' : ''}</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                  {novelList.map(n => <NovelCard key={n.id} novel={n} />)}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
