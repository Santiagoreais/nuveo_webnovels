export const dynamic = 'force-dynamic'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { db } from '@/db'
import { users, novels, chapters, votes, hypes } from '@/db/schema'
import { eq, and, desc, sql } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import NovelCard, { NovelCardData } from '@/components/NovelCard'
import { User, BookOpen, Eye, Flame, Star, Calendar } from 'lucide-react'
import { formatDate, formatNumber } from '@/lib/utils'

export default async function PerfilPage({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params
  const [currentUser] = await Promise.all([getSession()])

  const [profile] = await db.select().from(users).where(eq(users.username, username.toLowerCase())).limit(1)
  if (!profile) notFound()

  const authorNovels = await db.select({
    id: novels.id,
    title: novels.title,
    slug: novels.slug,
    description: novels.description,
    coverUrl: novels.coverUrl,
    genre: novels.genre,
    status: novels.status,
    views: novels.views,
    authorName: users.name,
    authorUsername: users.username,
    chapterCount: sql<number>`count(distinct ${chapters.id})::int`,
    avgRating: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
    totalVotes: sql<number>`count(distinct ${votes.id})::int`,
    hypeCount: sql<number>`count(distinct ${hypes.id})::int`,
  })
    .from(novels)
    .leftJoin(users, eq(novels.authorId, users.id))
    .leftJoin(chapters, and(eq(chapters.novelId, novels.id), eq(chapters.isDraft, false)))
    .leftJoin(votes, eq(votes.novelId, novels.id))
    .leftJoin(hypes, eq(hypes.novelId, novels.id))
    .where(eq(novels.authorId, profile.id))
    .groupBy(novels.id, users.name, users.username)
    .orderBy(desc(novels.createdAt))

  const totalViews = authorNovels.reduce((a, n) => a + n.views, 0)
  const totalHype = authorNovels.reduce((a, n) => a + n.hypeCount, 0)

  const roleLabel: Record<string, string> = {
    reader: 'Leitor',
    author: 'Autor',
    admin: 'Administrador',
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={currentUser} />
      <div className="mx-auto max-w-5xl px-4 py-8">

        {/* Profile header */}
        <div className="rounded-2xl border border-border bg-card p-6 mb-8">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
            <div className="h-20 w-20 rounded-2xl bg-primary/20 flex items-center justify-center overflow-hidden flex-shrink-0">
              {profile.avatarUrl ? (
                <img src={profile.avatarUrl} alt={profile.name} className="h-full w-full object-cover" />
              ) : (
                <span className="text-3xl font-bold text-primary">{profile.name[0].toUpperCase()}</span>
              )}
            </div>
            <div className="flex-1 text-center sm:text-left">
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-2 mb-2">
                <h1 className="text-2xl font-bold">{profile.name}</h1>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                  profile.role === 'admin' ? 'bg-red-400/10 text-red-400' :
                  profile.role === 'author' ? 'bg-purple-400/10 text-purple-400' :
                  'bg-blue-400/10 text-blue-400'
                }`}>
                  {roleLabel[profile.role] ?? profile.role}
                </span>
              </div>
              <p className="text-muted-foreground text-sm mb-1">@{profile.username}</p>
              {profile.bio && <p className="text-sm text-muted-foreground/80 mt-2 max-w-lg">{profile.bio}</p>}
              <div className="flex items-center gap-1 mt-3 text-xs text-muted-foreground">
                <Calendar className="h-3.5 w-3.5" />
                Membro desde {formatDate(profile.createdAt)}
              </div>
            </div>
          </div>

          {/* Stats */}
          {authorNovels.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-border">
              {[
                { icon: <BookOpen className="h-4 w-4 text-primary" />, label: 'Novelas', value: authorNovels.length },
                { icon: <Eye className="h-4 w-4 text-emerald-400" />, label: 'Leituras', value: formatNumber(totalViews) },
                { icon: <Flame className="h-4 w-4 text-amber-400" />, label: 'Total Hype', value: formatNumber(totalHype) },
                { icon: <Star className="h-4 w-4 text-gold" />, label: 'Obras', value: authorNovels.length },
              ].map(s => (
                <div key={s.label} className="text-center">
                  <div className="flex items-center justify-center gap-1.5 mb-1">{s.icon}</div>
                  <p className="text-xl font-bold">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Novels */}
        {authorNovels.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-6">Obras de {profile.name}</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {authorNovels.map(n => <NovelCard key={n.id} novel={n as NovelCardData} />)}
            </div>
          </div>
        )}

        {authorNovels.length === 0 && (
          <div className="text-center py-12 border border-dashed border-border rounded-xl">
            <BookOpen className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">Nenhuma obra publicada ainda.</p>
          </div>
        )}
      </div>
    </div>
  )
}
