import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { novels, chapters, comments, users } from '@/db/schema'
import { eq, and, asc, isNull } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import { z } from 'zod'

const schema = z.object({
  novelSlug: z.string(),
  chapterId: z.number().optional(),
  parentId: z.number().optional(),
  content: z.string().min(1).max(2000),
})

export async function POST(req: NextRequest) {
  try {
    const user = await getSession()
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos' }, { status: 400 })

    const { novelSlug, chapterId, parentId, content } = parsed.data

    const [novel] = await db.select({ id: novels.id }).from(novels).where(eq(novels.slug, novelSlug)).limit(1)
    if (!novel) return NextResponse.json({ error: 'Novel não encontrada' }, { status: 404 })

    const [comment] = await db.insert(comments).values({
      userId: user.id,
      novelId: novel.id,
      chapterId: chapterId ?? null,
      parentId: parentId ?? null,
      content,
    }).returning()

    const result = {
      ...comment,
      userName: user.name,
      userUsername: user.username,
      userAvatar: user.avatarUrl,
    }

    return NextResponse.json({ comment: result }, { status: 201 })
  } catch (err) {
    console.error('[comments POST]', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const novelSlug = searchParams.get('novelSlug')
    if (!novelSlug) return NextResponse.json({ error: 'novelSlug obrigatório' }, { status: 400 })

    const [novel] = await db.select({ id: novels.id }).from(novels).where(eq(novels.slug, novelSlug)).limit(1)
    if (!novel) return NextResponse.json({ comments: [] })

    const rows = await db
      .select({
        id: comments.id,
        content: comments.content,
        parentId: comments.parentId,
        chapterId: comments.chapterId,
        createdAt: comments.createdAt,
        userId: comments.userId,
        userName: users.name,
        userUsername: users.username,
        userAvatar: users.avatarUrl,
      })
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .where(and(eq(comments.novelId, novel.id), eq(comments.isDeleted, false), isNull(comments.chapterId)))
      .orderBy(asc(comments.createdAt))

    return NextResponse.json({ comments: rows })
  } catch (err) {
    console.error('[comments GET]', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}
