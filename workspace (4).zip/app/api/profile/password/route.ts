import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { users } from '@/db/schema'
import { eq } from 'drizzle-orm'
import { getSession, verifyPassword, hashPassword } from '@/lib/auth'
import { z } from 'zod'

const schema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(6).max(72),
})

export async function PATCH(req: NextRequest) {
  try {
    const user = await getSession()
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos' }, { status: 400 })

    const [full] = await db.select({ passwordHash: users.passwordHash })
      .from(users).where(eq(users.id, user.id)).limit(1)

    const ok = await verifyPassword(parsed.data.currentPassword, full.passwordHash)
    if (!ok) return NextResponse.json({ error: 'Senha atual incorreta' }, { status: 403 })

    const newHash = await hashPassword(parsed.data.newPassword)
    await db.update(users).set({ passwordHash: newHash, updatedAt: new Date() }).where(eq(users.id, user.id))

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[password PATCH]', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}
