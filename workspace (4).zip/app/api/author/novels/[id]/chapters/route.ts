import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { novels, chapters } from '@/db/schema'
import { eq, and, desc, sql } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import { countWords } from '@/lib/utils'
import { z } from 'zod'

const schema = z.object({
  title: z.string().min(1).max(300),
  content: z.string().min(1),
  isDraft: z.boolean().default(false),
})

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getSession()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { id } = await params
  const novelId = parseInt(id)

  const [novel] = await db.select({ id: novels.id, authorId: novels.authorId })
    .from(novels).where(eq(novels.id, novelId)).limit(1)

  if (!novel || (novel.authorId !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 403 })
  }

  const body = await req.json()
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos' }, { status: 400 })

  // Get next chapter number
  const [{ max }] = await db.select({ max: sql<number>`coalesce(max(${chapters.number}), 0)` })
    .from(chapters).where(eq(chapters.novelId, novelId))

  const wordCount = countWords(parsed.data.content)

  const [chapter] = await db.insert(chapters).values({
    novelId,
    number: max + 1,
    title: parsed.data.title,
    content: parsed.data.content,
    wordCount,
    isDraft: parsed.data.isDraft,
  }).returning()

  // Update novel total word count
  const [wc] = await db.select({ total: sql<number>`coalesce(sum(${chapters.wordCount}), 0)::int` })
    .from(chapters).where(eq(chapters.novelId, novelId))
  await db.update(novels).set({ wordCount: wc.total, updatedAt: new Date() }).where(eq(novels.id, novelId))

  return NextResponse.json({ chapter }, { status: 201 })
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getSession()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const { id } = await params
  const novelId = parseInt(id)

  const [novel] = await db.select({ id: novels.id, authorId: novels.authorId })
    .from(novels).where(eq(novels.id, novelId)).limit(1)

  if (!novel || (novel.authorId !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 403 })
  }

  const chapterList = await db.select().from(chapters)
    .where(eq(chapters.novelId, novelId))
    .orderBy(desc(chapters.number))

  return NextResponse.json({ chapters: chapterList })
}
