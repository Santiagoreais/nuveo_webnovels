import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { novels, chapters, votes, hypes } from '@/db/schema'
import { eq, desc, sql, and } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import { generateSlug } from '@/lib/utils'
import { z } from 'zod'

const createSchema = z.object({
  title: z.string().min(2).max(200),
  description: z.string().min(10).max(5000),
  coverUrl: z.string().url().optional().or(z.literal('')),
  genre: z.string(),
  tags: z.string().optional(),
  status: z.enum(['active', 'completed', 'hiatus', 'cancelled']).default('active'),
})

export async function GET(_req: NextRequest) {
  const user = await getSession()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const rows = await db.select({
    id: novels.id,
    title: novels.title,
    slug: novels.slug,
    status: novels.status,
    genre: novels.genre,
    views: novels.views,
    createdAt: novels.createdAt,
    chapterCount: sql<number>`count(distinct ${chapters.id})::int`,
    avgRating: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
    hypeCount: sql<number>`count(distinct ${hypes.id})::int`,
  })
    .from(novels)
    .leftJoin(chapters, and(eq(chapters.novelId, novels.id), eq(chapters.isDraft, false)))
    .leftJoin(votes, eq(votes.novelId, novels.id))
    .leftJoin(hypes, eq(hypes.novelId, novels.id))
    .where(eq(novels.authorId, user.id))
    .groupBy(novels.id)
    .orderBy(desc(novels.createdAt))

  return NextResponse.json({ novels: rows })
}

export async function POST(req: NextRequest) {
  const user = await getSession()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })
  if (user.role === 'reader') return NextResponse.json({ error: 'Apenas autores podem publicar' }, { status: 403 })

  const body = await req.json()
  const parsed = createSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos', details: parsed.error.flatten() }, { status: 400 })

  const slug = generateSlug(parsed.data.title)
  const [novel] = await db.insert(novels).values({
    authorId: user.id,
    title: parsed.data.title,
    slug,
    description: parsed.data.description,
    coverUrl: parsed.data.coverUrl || null,
    genre: parsed.data.genre as never,
    tags: parsed.data.tags || null,
    status: parsed.data.status,
  }).returning()

  return NextResponse.json({ novel }, { status: 201 })
}
