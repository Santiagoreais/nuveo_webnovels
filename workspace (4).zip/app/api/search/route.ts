import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { novels, users, chapters, votes, hypes } from '@/db/schema'
import { eq, desc, ilike, and, or, gte, lte, sql } from 'drizzle-orm'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const q = searchParams.get('q')?.trim() ?? ''
    const genre = searchParams.get('genre') ?? ''
    const status = searchParams.get('status') ?? ''
    const sort = searchParams.get('sort') ?? 'recent'
    const minChapters = parseInt(searchParams.get('minChapters') ?? '0')
    const page = Math.max(1, parseInt(searchParams.get('page') ?? '1'))
    const limit = 20
    const offset = (page - 1) * limit

    const conditions: ReturnType<typeof eq>[] = []
    if (genre) conditions.push(eq(novels.genre, genre as never))
    if (status) conditions.push(eq(novels.status, status as never))
    if (q) {
      conditions.push(
        or(
          ilike(novels.title, `%${q}%`),
          ilike(novels.description, `%${q}%`)
        ) as ReturnType<typeof eq>
      )
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined

    const rows = await db
      .select({
        id: novels.id,
        title: novels.title,
        slug: novels.slug,
        description: novels.description,
        coverUrl: novels.coverUrl,
        genre: novels.genre,
        status: novels.status,
        views: novels.views,
        wordCount: novels.wordCount,
        createdAt: novels.createdAt,
        authorName: users.name,
        authorUsername: users.username,
        authorAvatar: users.avatarUrl,
        chapterCount: sql<number>`count(distinct ${chapters.id})::int`,
        avgRating: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
        totalVotes: sql<number>`count(distinct ${votes.id})::int`,
        hypeCount: sql<number>`count(distinct ${hypes.id})::int`,
      })
      .from(novels)
      .leftJoin(users, eq(novels.authorId, users.id))
      .leftJoin(chapters, and(eq(chapters.novelId, novels.id), eq(chapters.isDraft, false)))
      .leftJoin(votes, eq(votes.novelId, novels.id))
      .leftJoin(hypes, eq(hypes.novelId, novels.id))
      .where(whereClause)
      .groupBy(novels.id, users.name, users.username, users.avatarUrl)
      .having(
        minChapters > 0
          ? gte(sql<number>`count(distinct ${chapters.id})`, minChapters)
          : undefined
      )
      .orderBy(
        sort === 'views' ? desc(novels.views) :
        sort === 'hype'  ? desc(sql`count(distinct ${hypes.id})`) :
        sort === 'rating'? desc(sql`coalesce(avg(${votes.value}),0)`) :
        sort === 'alpha' ? novels.title :
        desc(novels.createdAt)
      )
      .limit(limit)
      .offset(offset)

    const [{ total }] = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(novels)
      .leftJoin(chapters, and(eq(chapters.novelId, novels.id), eq(chapters.isDraft, false)))
      .where(whereClause)
      .groupBy(sql`1`)
      .limit(1)
      .catch(() => [{ total: 0 }])

    return NextResponse.json({ results: rows, total: total ?? 0, page, limit })
  } catch (err) {
    console.error('[search]', err)
    return NextResponse.json({ results: [], total: 0, page: 1, limit: 20 })
  }
}
