import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { bookmarks } from '@/db/schema'
import { eq, and } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import { z } from 'zod'

const schema = z.object({ novelId: z.number() })

export async function POST(req: NextRequest) {
  const user = await getSession()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })
  const body = await req.json()
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Inválido' }, { status: 400 })
  const { novelId } = parsed.data
  const [existing] = await db.select({ id: bookmarks.id }).from(bookmarks)
    .where(and(eq(bookmarks.userId, user.id), eq(bookmarks.novelId, novelId))).limit(1)
  if (!existing) {
    await db.insert(bookmarks).values({ userId: user.id, novelId })
  }
  return NextResponse.json({ ok: true })
}

export async function DELETE(req: NextRequest) {
  const user = await getSession()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })
  const body = await req.json()
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Inválido' }, { status: 400 })
  await db.delete(bookmarks).where(and(eq(bookmarks.userId, user.id), eq(bookmarks.novelId, parsed.data.novelId)))
  return NextResponse.json({ ok: true })
}
