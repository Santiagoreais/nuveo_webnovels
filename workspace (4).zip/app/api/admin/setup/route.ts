import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { users } from '@/db/schema'
import { eq, sql } from 'drizzle-orm'
import { z } from 'zod'

const schema = z.object({
  username: z.string().min(1),
  secret: z.string().min(1),
})

// Segredo fixo de setup — só funciona se NÃO houver nenhum admin ainda
const SETUP_SECRET = process.env.ADMIN_SETUP_SECRET ?? 'nuveo-setup-2024'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Dados inválidos' }, { status: 400 })
    }
    const { username, secret } = parsed.data

    // Verifica o segredo
    if (secret !== SETUP_SECRET) {
      return NextResponse.json({ error: 'Segredo incorreto' }, { status: 403 })
    }

    // Só funciona se não houver nenhum admin no banco
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(eq(users.role, 'admin'))

    if (count > 0) {
      return NextResponse.json(
        { error: 'Já existe um administrador. Use o painel admin para gerenciar cargos.' },
        { status: 409 }
      )
    }

    // Promove o usuário
    const [user] = await db
      .update(users)
      .set({ role: 'admin', updatedAt: new Date() })
      .where(eq(users.username, username.toLowerCase()))
      .returning({ id: users.id, name: users.name, username: users.username, role: users.role })

    if (!user) {
      return NextResponse.json({ error: 'Usuário não encontrado' }, { status: 404 })
    }

    return NextResponse.json({ ok: true, user })
  } catch (err) {
    console.error('[admin setup]', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}
