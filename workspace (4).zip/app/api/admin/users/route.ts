import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { users } from '@/db/schema'
import { eq, desc } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import { z } from 'zod'

const patchSchema = z.object({
  userId: z.number(),
  role: z.enum(['reader', 'author', 'admin']),
})

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== 'admin') return NextResponse.json({ error: 'Não autorizado' }, { status: 403 })

  const body = await req.json()
  const parsed = patchSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos' }, { status: 400 })

  const { userId, role } = parsed.data
  if (userId === session.id) return NextResponse.json({ error: 'Não pode alterar seu próprio cargo' }, { status: 400 })

  await db.update(users).set({ role, updatedAt: new Date() }).where(eq(users.id, userId))
  return NextResponse.json({ ok: true })
}

export async function GET(_req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== 'admin') return NextResponse.json({ error: 'Não autorizado' }, { status: 403 })

  const all = await db.select({
    id: users.id, name: users.name, username: users.username,
    email: users.email, role: users.role, createdAt: users.createdAt,
  }).from(users).orderBy(desc(users.createdAt))

  return NextResponse.json({ users: all })
}
