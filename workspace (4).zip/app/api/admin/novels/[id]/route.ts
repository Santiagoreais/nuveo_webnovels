import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { novels } from '@/db/schema'
import { eq } from 'drizzle-orm'
import { getSession } from '@/lib/auth'

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getSession()
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Não autorizado' }, { status: 403 })
  const { id } = await params
  await db.delete(novels).where(eq(novels.id, parseInt(id)))
  return NextResponse.json({ ok: true })
}
