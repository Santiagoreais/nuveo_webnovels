import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { comments } from '@/db/schema'
import { eq } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import { z } from 'zod'

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getSession()
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Não autorizado' }, { status: 403 })
  const { id } = await params
  const { isDeleted } = await req.json()
  await db.update(comments).set({ isDeleted: Boolean(isDeleted) }).where(eq(comments.id, parseInt(id)))
  return NextResponse.json({ ok: true })
}
