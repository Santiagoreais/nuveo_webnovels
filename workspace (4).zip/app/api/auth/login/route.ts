import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { users } from '@/db/schema'
import { eq, or } from 'drizzle-orm'
import { verifyPassword, createSession } from '@/lib/auth'
import { z } from 'zod'

const schema = z.object({
  // aceita email OU username no campo "identifier"
  identifier: z.string().min(1),
  password: z.string().min(1),
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Dados inválidos' }, { status: 400 })
    }
    const { identifier, password } = parsed.data
    const id = identifier.toLowerCase().trim()

    // Busca por email OU username
    const [user] = await db
      .select()
      .from(users)
      .where(or(eq(users.email, id), eq(users.username, id)))
      .limit(1)

    if (!user) {
      return NextResponse.json({ error: 'Usuário ou senha incorretos' }, { status: 401 })
    }

    const ok = await verifyPassword(password, user.passwordHash)
    if (!ok) {
      return NextResponse.json({ error: 'Usuário ou senha incorretos' }, { status: 401 })
    }

    const sessionUser = {
      id: user.id,
      name: user.name,
      username: user.username,
      email: user.email,
      role: user.role,
      avatarUrl: user.avatarUrl,
    }
    await createSession(sessionUser)
    return NextResponse.json({ user: sessionUser })
  } catch (err) {
    console.error('[login]', err)
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 })
  }
}
