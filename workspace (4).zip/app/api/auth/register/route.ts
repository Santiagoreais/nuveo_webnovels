import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { users } from '@/db/schema'
import { eq, or } from 'drizzle-orm'
import { hashPassword, createSession } from '@/lib/auth'
import { generateSlug } from '@/lib/utils'
import { z } from 'zod'

const schema = z.object({
  name: z.string().min(2).max(60),
  username: z.string().min(3).max(30).regex(/^[a-z0-9_-]+$/i),
  email: z.string().email(),
  password: z.string().min(6).max(72),
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Dados inválidos', details: parsed.error.flatten() }, { status: 400 })
    }
    const { name, username, email, password } = parsed.data

    const existing = await db.select({ id: users.id }).from(users)
      .where(or(eq(users.email, email.toLowerCase()), eq(users.username, username.toLowerCase())))
      .limit(1)

    if (existing.length > 0) {
      return NextResponse.json({ error: 'Email ou username já em uso' }, { status: 409 })
    }

    const passwordHash = await hashPassword(password)
    const [user] = await db.insert(users).values({
      name,
      username: username.toLowerCase(),
      email: email.toLowerCase(),
      passwordHash,
      role: 'reader',
    }).returning({
      id: users.id,
      name: users.name,
      username: users.username,
      email: users.email,
      role: users.role,
      avatarUrl: users.avatarUrl,
    })

    await createSession(user)
    return NextResponse.json({ user }, { status: 201 })
  } catch (err) {
    console.error('[register]', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}
