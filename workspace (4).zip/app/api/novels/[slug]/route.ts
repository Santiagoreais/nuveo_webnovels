import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { novels, users, chapters, votes, hypes } from '@/db/schema'
import { eq, sql, and, asc } from 'drizzle-orm'

export async function GET(_req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params

    const [novel] = await db
      .select({
        id: novels.id,
        title: novels.title,
        slug: novels.slug,
        description: novels.description,
        coverUrl: novels.coverUrl,
        genre: novels.genre,
        tags: novels.tags,
        status: novels.status,
        views: novels.views,
        wordCount: novels.wordCount,
        publishedAt: novels.publishedAt,
        createdAt: novels.createdAt,
        authorId: novels.authorId,
        authorName: users.name,
        authorUsername: users.username,
        authorBio: users.bio,
        authorAvatar: users.avatarUrl,
        avgRating: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
        totalVotes: sql<number>`count(distinct ${votes.id})::int`,
        hypeCount: sql<number>`count(distinct ${hypes.id})::int`,
      })
      .from(novels)
      .leftJoin(users, eq(novels.authorId, users.id))
      .leftJoin(votes, eq(votes.novelId, novels.id))
      .leftJoin(hypes, eq(hypes.novelId, novels.id))
      .where(eq(novels.slug, slug))
      .groupBy(novels.id, users.name, users.username, users.bio, users.avatarUrl)
      .limit(1)

    if (!novel) return NextResponse.json({ error: 'Novel não encontrada' }, { status: 404 })

    // Increment views
    await db.update(novels).set({ views: sql`${novels.views} + 1` }).where(eq(novels.id, novel.id))

    // Fetch chapters
    const chapterList = await db
      .select({
        id: chapters.id,
        number: chapters.number,
        title: chapters.title,
        wordCount: chapters.wordCount,
        views: chapters.views,
        publishedAt: chapters.publishedAt,
      })
      .from(chapters)
      .where(and(eq(chapters.novelId, novel.id), eq(chapters.isDraft, false)))
      .orderBy(asc(chapters.number))

    return NextResponse.json({ novel, chapters: chapterList })
  } catch (err) {
    console.error('[novel GET]', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}
