import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { chapters, novels, comments, users } from '@/db/schema'
import { eq, and, sql, asc } from 'drizzle-orm'

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ slug: string; number: string }> }
) {
  try {
    const { slug, number } = await params
    const num = parseInt(number)
    if (isNaN(num)) return NextResponse.json({ error: 'Inválido' }, { status: 400 })

    const [novel] = await db.select({ id: novels.id, title: novels.title, slug: novels.slug })
      .from(novels).where(eq(novels.slug, slug)).limit(1)
    if (!novel) return NextResponse.json({ error: 'Novel não encontrada' }, { status: 404 })

    const [chapter] = await db.select()
      .from(chapters)
      .where(and(eq(chapters.novelId, novel.id), eq(chapters.number, num), eq(chapters.isDraft, false)))
      .limit(1)
    if (!chapter) return NextResponse.json({ error: 'Capítulo não encontrado' }, { status: 404 })

    // Increment chapter views
    await db.update(chapters).set({ views: sql`${chapters.views} + 1` }).where(eq(chapters.id, chapter.id))

    // Prev/Next
    const [prev] = await db.select({ number: chapters.number, title: chapters.title })
      .from(chapters)
      .where(and(eq(chapters.novelId, novel.id), eq(chapters.isDraft, false), sql`${chapters.number} < ${num}`))
      .orderBy(sql`${chapters.number} DESC`)
      .limit(1)

    const [next] = await db.select({ number: chapters.number, title: chapters.title })
      .from(chapters)
      .where(and(eq(chapters.novelId, novel.id), eq(chapters.isDraft, false), sql`${chapters.number} > ${num}`))
      .orderBy(asc(chapters.number))
      .limit(1)

    // Comments for this chapter
    const chapterComments = await db
      .select({
        id: comments.id,
        content: comments.content,
        parentId: comments.parentId,
        createdAt: comments.createdAt,
        userId: comments.userId,
        userName: users.name,
        userUsername: users.username,
        userAvatar: users.avatarUrl,
      })
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .where(and(eq(comments.chapterId, chapter.id), eq(comments.isDeleted, false)))
      .orderBy(asc(comments.createdAt))

    return NextResponse.json({ novel, chapter, prev: prev ?? null, next: next ?? null, comments: chapterComments })
  } catch (err) {
    console.error('[chapter GET]', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}
