import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { novels, hypes } from '@/db/schema'
import { eq, and, sql } from 'drizzle-orm'
import { getSession } from '@/lib/auth'

export async function POST(_req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const user = await getSession()
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

    const { slug } = await params
    const [novel] = await db.select({ id: novels.id }).from(novels).where(eq(novels.slug, slug)).limit(1)
    if (!novel) return NextResponse.json({ error: 'Novel não encontrada' }, { status: 404 })

    const today = new Date().toISOString().slice(0, 10)

    const [existing] = await db.select({ id: hypes.id })
      .from(hypes)
      .where(and(eq(hypes.userId, user.id), eq(hypes.novelId, novel.id), eq(hypes.hypeDate, today)))
      .limit(1)

    if (existing) {
      return NextResponse.json({ error: 'Você já deu hype hoje nessa novel', alreadyHyped: true }, { status: 409 })
    }

    await db.insert(hypes).values({ userId: user.id, novelId: novel.id, hypeDate: today })

    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` })
      .from(hypes).where(eq(hypes.novelId, novel.id))

    return NextResponse.json({ hypeCount: count, hyped: true })
  } catch (err) {
    console.error('[hype POST]', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const user = await getSession()
    const { slug } = await params
    const [novel] = await db.select({ id: novels.id }).from(novels).where(eq(novels.slug, slug)).limit(1)
    if (!novel) return NextResponse.json({ hyped: false, hypeCount: 0 })

    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` })
      .from(hypes).where(eq(hypes.novelId, novel.id))

    let hyped = false
    if (user) {
      const today = new Date().toISOString().slice(0, 10)
      const [existing] = await db.select({ id: hypes.id })
        .from(hypes)
        .where(and(eq(hypes.userId, user.id), eq(hypes.novelId, novel.id), eq(hypes.hypeDate, today)))
        .limit(1)
      hyped = !!existing
    }

    return NextResponse.json({ hyped, hypeCount: count })
  } catch (err) {
    return NextResponse.json({ hyped: false, hypeCount: 0 })
  }
}
