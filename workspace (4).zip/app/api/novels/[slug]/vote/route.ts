import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { novels, votes } from '@/db/schema'
import { eq, and, sql } from 'drizzle-orm'
import { getSession } from '@/lib/auth'

export async function POST(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const user = await getSession()
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

    const { slug } = await params
    const body = await req.json()
    const value = parseInt(body.value)
    if (isNaN(value) || value < 1 || value > 5) {
      return NextResponse.json({ error: 'Valor deve ser entre 1 e 5' }, { status: 400 })
    }

    const [novel] = await db.select({ id: novels.id }).from(novels).where(eq(novels.slug, slug)).limit(1)
    if (!novel) return NextResponse.json({ error: 'Novel não encontrada' }, { status: 404 })

    const [existing] = await db.select({ id: votes.id })
      .from(votes)
      .where(and(eq(votes.userId, user.id), eq(votes.novelId, novel.id)))
      .limit(1)

    if (existing) {
      await db.update(votes).set({ value }).where(eq(votes.id, existing.id))
    } else {
      await db.insert(votes).values({ userId: user.id, novelId: novel.id, value })
    }

    const [stats] = await db.select({
      avg: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
      count: sql<number>`count(*)::int`,
    }).from(votes).where(eq(votes.novelId, novel.id))

    return NextResponse.json({ avgRating: stats.avg, totalVotes: stats.count, userVote: value })
  } catch (err) {
    console.error('[vote POST]', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const user = await getSession()
    const { slug } = await params
    const [novel] = await db.select({ id: novels.id }).from(novels).where(eq(novels.slug, slug)).limit(1)
    if (!novel) return NextResponse.json({ avgRating: 0, totalVotes: 0, userVote: null })

    const [stats] = await db.select({
      avg: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
      count: sql<number>`count(*)::int`,
    }).from(votes).where(eq(votes.novelId, novel.id))

    let userVote = null
    if (user) {
      const [uv] = await db.select({ value: votes.value })
        .from(votes)
        .where(and(eq(votes.userId, user.id), eq(votes.novelId, novel.id)))
        .limit(1)
      userVote = uv?.value ?? null
    }

    return NextResponse.json({ avgRating: stats.avg, totalVotes: stats.count, userVote })
  } catch (err) {
    return NextResponse.json({ avgRating: 0, totalVotes: 0, userVote: null })
  }
}
