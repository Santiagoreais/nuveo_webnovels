import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { novels, users, chapters, votes, hypes } from '@/db/schema'
import { eq, desc, sql, ilike, and } from 'drizzle-orm'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const page = Math.max(1, parseInt(searchParams.get('page') ?? '1'))
    const limit = Math.min(50, parseInt(searchParams.get('limit') ?? '20'))
    const offset = (page - 1) * limit
    const genre = searchParams.get('genre')
    const status = searchParams.get('status')
    const search = searchParams.get('q')
    const sort = searchParams.get('sort') ?? 'recent'

    const conditions = []
    if (genre) conditions.push(eq(novels.genre, genre as never))
    if (status) conditions.push(eq(novels.status, status as never))
    if (search) conditions.push(ilike(novels.title, `%${search}%`))

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined

    const rows = await db
      .select({
        id: novels.id,
        title: novels.title,
        slug: novels.slug,
        description: novels.description,
        coverUrl: novels.coverUrl,
        genre: novels.genre,
        status: novels.status,
        views: novels.views,
        createdAt: novels.createdAt,
        authorName: users.name,
        authorUsername: users.username,
        chapterCount: sql<number>`count(distinct ${chapters.id})::int`,
        avgRating: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
        totalVotes: sql<number>`count(distinct ${votes.id})::int`,
        hypeCount: sql<number>`count(distinct ${hypes.id})::int`,
      })
      .from(novels)
      .leftJoin(users, eq(novels.authorId, users.id))
      .leftJoin(chapters, and(eq(chapters.novelId, novels.id), eq(chapters.isDraft, false)))
      .leftJoin(votes, eq(votes.novelId, novels.id))
      .leftJoin(hypes, eq(hypes.novelId, novels.id))
      .where(whereClause)
      .groupBy(novels.id, users.name, users.username)
      .orderBy(sort === 'views' ? desc(novels.views) : desc(novels.createdAt))
      .limit(limit)
      .offset(offset)

    return NextResponse.json({ novels: rows, page, limit })
  } catch (err) {
    console.error('[novels GET]', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}
