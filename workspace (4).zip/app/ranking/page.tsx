export const dynamic = 'force-dynamic'
import Link from 'next/link'
import { db } from '@/db'
import { novels, users, chapters, votes, hypes } from '@/db/schema'
import { eq, desc, sql, and } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import { Flame, Star, Eye, BookOpen, Trophy } from 'lucide-react'
import { formatNumber, GENRE_LABELS, STATUS_COLORS, STATUS_LABELS, cn } from '@/lib/utils'

async function getRanking(by: 'hype' | 'rating' | 'views') {
  return db.select({
    id: novels.id,
    title: novels.title,
    slug: novels.slug,
    description: novels.description,
    coverUrl: novels.coverUrl,
    genre: novels.genre,
    status: novels.status,
    views: novels.views,
    authorName: users.name,
    authorUsername: users.username,
    chapterCount: sql<number>`count(distinct ${chapters.id})::int`,
    avgRating: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
    totalVotes: sql<number>`count(distinct ${votes.id})::int`,
    hypeCount: sql<number>`count(distinct ${hypes.id})::int`,
  })
    .from(novels)
    .leftJoin(users, eq(novels.authorId, users.id))
    .leftJoin(chapters, and(eq(chapters.novelId, novels.id), eq(chapters.isDraft, false)))
    .leftJoin(votes, eq(votes.novelId, novels.id))
    .leftJoin(hypes, eq(hypes.novelId, novels.id))
    .groupBy(novels.id, users.name, users.username)
    .orderBy(
      by === 'hype' ? desc(sql`count(distinct ${hypes.id})`) :
      by === 'rating' ? desc(sql`avg(${votes.value})`) :
      desc(novels.views)
    )
    .limit(20)
}

export default async function RankingPage({
  searchParams,
}: {
  searchParams: Promise<{ by?: string }>
}) {
  const params = await searchParams
  const by = (params.by ?? 'hype') as 'hype' | 'rating' | 'views'
  const [user, ranking] = await Promise.all([getSession(), getRanking(by)])

  const tabs = [
    { value: 'hype', label: 'Hype', icon: <Flame className="h-4 w-4" /> },
    { value: 'rating', label: 'Avaliação', icon: <Star className="h-4 w-4" /> },
    { value: 'views', label: 'Leituras', icon: <Eye className="h-4 w-4" /> },
  ]

  const rankColors = ['text-amber-400', 'text-slate-300', 'text-amber-600']

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <div className="mx-auto max-w-4xl px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2.5 rounded-xl bg-amber-400/10 border border-amber-400/20">
            <Trophy className="h-6 w-6 text-amber-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Ranking</h1>
            <p className="text-sm text-muted-foreground">As melhores webnovels da plataforma</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl bg-card border border-border mb-8">
          {tabs.map(t => (
            <Link key={t.value} href={`/ranking?by=${t.value}`}
              className={cn(
                'flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-lg text-sm font-medium transition-all',
                by === t.value
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              )}>
              {t.icon} {t.label}
            </Link>
          ))}
        </div>

        {/* Ranking list */}
        {ranking.length === 0 ? (
          <div className="text-center py-16 border border-dashed border-border rounded-xl">
            <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Nenhuma novel publicada ainda.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {ranking.map((novel, i) => (
              <Link key={novel.id} href={`/historias/${novel.slug}`}
                className="flex items-center gap-4 p-4 rounded-xl border border-border bg-card hover:border-primary/40 hover:bg-accent/30 transition-all group">
                {/* Rank number */}
                <div className="flex items-center justify-center w-10 flex-shrink-0">
                  {i < 3 ? (
                    <Trophy className={cn('h-6 w-6', rankColors[i])} />
                  ) : (
                    <span className="text-xl font-bold text-muted-foreground">{i + 1}</span>
                  )}
                </div>

                {/* Cover */}
                <div className="w-14 h-20 rounded-lg flex-shrink-0 overflow-hidden bg-primary/10">
                  {novel.coverUrl ? (
                    <img src={novel.coverUrl} alt={novel.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full cover-gradient" />
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold truncate group-hover:text-primary transition-colors">{novel.title}</h3>
                    <span className={cn('text-[10px] font-semibold px-1.5 py-0.5 rounded flex-shrink-0', STATUS_COLORS[novel.status])}>
                      {STATUS_LABELS[novel.status]}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">{novel.authorName} · {GENRE_LABELS[novel.genre] ?? novel.genre}</p>
                  <p className="text-xs text-muted-foreground line-clamp-1">{novel.description}</p>
                </div>

                {/* Stats */}
                <div className="flex flex-col items-end gap-1.5 flex-shrink-0 text-sm">
                  <span className="flex items-center gap-1.5 font-bold">
                    {by === 'hype' && <><Flame className="h-4 w-4 text-amber-400" /><span className="text-amber-400">{formatNumber(novel.hypeCount)}</span></>}
                    {by === 'rating' && <><Star className="h-4 w-4 fill-gold text-gold" /><span className="text-gold">{novel.avgRating.toFixed(1)}</span></>}
                    {by === 'views' && <><Eye className="h-4 w-4 text-primary" /><span className="text-primary">{formatNumber(novel.views)}</span></>}
                  </span>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><BookOpen className="h-3 w-3" />{novel.chapterCount}</span>
                    {by !== 'hype' && <span className="flex items-center gap-1"><Flame className="h-3 w-3 text-amber-400" />{formatNumber(novel.hypeCount)}</span>}
                    {by !== 'rating' && <span className="flex items-center gap-1"><Star className="h-3 w-3 text-gold" />{novel.avgRating.toFixed(1)}</span>}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
