export const dynamic = 'force-dynamic'
import Link from 'next/link'
import { db } from '@/db'
import { novels, users, chapters, votes, hypes } from '@/db/schema'
import { eq, desc, sql, and } from 'drizzle-orm'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import NovelCard, { NovelCardData } from '@/components/NovelCard'
import { Flame, TrendingUp, BookOpen, Clock, ChevronRight, Star } from 'lucide-react'
import { formatNumber } from '@/lib/utils'

async function getFeaturedNovels(): Promise<NovelCardData[]> {
  const rows = await db.select({
    id: novels.id,
    title: novels.title,
    slug: novels.slug,
    description: novels.description,
    coverUrl: novels.coverUrl,
    genre: novels.genre,
    status: novels.status,
    views: novels.views,
    authorName: users.name,
    authorUsername: users.username,
    chapterCount: sql<number>`count(distinct ${chapters.id})::int`,
    avgRating: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
    totalVotes: sql<number>`count(distinct ${votes.id})::int`,
    hypeCount: sql<number>`count(distinct ${hypes.id})::int`,
  })
    .from(novels)
    .leftJoin(users, eq(novels.authorId, users.id))
    .leftJoin(chapters, and(eq(chapters.novelId, novels.id), eq(chapters.isDraft, false)))
    .leftJoin(votes, eq(votes.novelId, novels.id))
    .leftJoin(hypes, eq(hypes.novelId, novels.id))
    .groupBy(novels.id, users.name, users.username)
    .orderBy(desc(novels.views))
    .limit(8)
  return rows as NovelCardData[]
}

async function getHypeRanking(): Promise<NovelCardData[]> {
  const rows = await db.select({
    id: novels.id,
    title: novels.title,
    slug: novels.slug,
    description: novels.description,
    coverUrl: novels.coverUrl,
    genre: novels.genre,
    status: novels.status,
    views: novels.views,
    authorName: users.name,
    authorUsername: users.username,
    chapterCount: sql<number>`count(distinct ${chapters.id})::int`,
    avgRating: sql<number>`coalesce(avg(${votes.value}), 0)::float`,
    totalVotes: sql<number>`count(distinct ${votes.id})::int`,
    hypeCount: sql<number>`count(distinct ${hypes.id})::int`,
  })
    .from(novels)
    .leftJoin(users, eq(novels.authorId, users.id))
    .leftJoin(chapters, and(eq(chapters.novelId, novels.id), eq(chapters.isDraft, false)))
    .leftJoin(votes, eq(votes.novelId, novels.id))
    .leftJoin(hypes, eq(hypes.novelId, novels.id))
    .groupBy(novels.id, users.name, users.username)
    .orderBy(desc(sql`count(distinct ${hypes.id})`))
    .limit(5)
  return rows as NovelCardData[]
}

async function getRecentChapters() {
  return db.select({
    chapterId: chapters.id,
    chapterNumber: chapters.number,
    chapterTitle: chapters.title,
    publishedAt: chapters.publishedAt,
    novelId: novels.id,
    novelTitle: novels.title,
    novelSlug: novels.slug,
    novelCover: novels.coverUrl,
    authorName: users.name,
  })
    .from(chapters)
    .leftJoin(novels, eq(chapters.novelId, novels.id))
    .leftJoin(users, eq(novels.authorId, users.id))
    .where(eq(chapters.isDraft, false))
    .orderBy(desc(chapters.publishedAt))
    .limit(10)
}

export default async function HomePage() {
  const [user, featured, hypeRanking, recentChapters] = await Promise.all([
    getSession(),
    getFeaturedNovels(),
    getHypeRanking(),
    getRecentChapters(),
  ])

  const isEmpty = featured.length === 0

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_oklch(0.6_0.22_295_/_0.15),_transparent_60%)]" />
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:py-28 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm text-primary mb-6">
            <Flame className="h-3.5 w-3.5" />
            Plataforma de Webnovels BR/PT
          </div>
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tight mb-4">
            <span className="text-primary">Nu</span>
            <span>veo</span>
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Onde histórias ganham vida. Leia e publique webnovels originais em português, de autores brasileiros e portugueses.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link href="/historias" className="px-6 py-3 rounded-lg bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors">
              Explorar Histórias
            </Link>
            {!user && (
              <Link href="/registro" className="px-6 py-3 rounded-lg border border-border hover:bg-accent transition-colors font-semibold">
                Criar Conta Grátis
              </Link>
            )}
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-7xl px-4 py-10 space-y-14">

        {/* Empty state */}
        {isEmpty && (
          <div className="text-center py-16 border border-dashed border-border rounded-xl">
            <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Seja o primeiro a publicar!</h2>
            <p className="text-muted-foreground mb-6">Nenhuma novel publicada ainda. Comece criando sua conta e compartilhe sua história.</p>
            {user ? (
              <Link href="/minha-area" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-colors">
                <BookOpen className="h-4 w-4" /> Publicar Novel
              </Link>
            ) : (
              <Link href="/registro" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-colors">
                Criar Conta
              </Link>
            )}
          </div>
        )}

        {/* Featured Novels */}
        {featured.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                <h2 className="text-xl font-bold">Em Destaque</h2>
              </div>
              <Link href="/historias" className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors">
                Ver todas <ChevronRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {featured.slice(0, 6).map(n => <NovelCard key={n.id} novel={n} />)}
            </div>
          </section>
        )}

        {/* Hype Ranking + Recent Chapters */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* Hype Ranking */}
          {hypeRanking.length > 0 && (
            <div className="lg:col-span-1">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-amber-400" />
                  <h2 className="text-lg font-bold">Ranking de Hype</h2>
                </div>
                <Link href="/ranking" className="text-xs text-muted-foreground hover:text-primary transition-colors">
                  Ver ranking
                </Link>
              </div>
              <div className="space-y-2">
                {hypeRanking.map((n, i) => (
                  <Link key={n.id} href={`/historias/${n.slug}`} className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card hover:border-primary/40 hover:bg-accent/50 transition-all group">
                    <span className={`text-lg font-bold w-6 text-center flex-shrink-0 ${i === 0 ? 'text-amber-400' : i === 1 ? 'text-slate-300' : i === 2 ? 'text-amber-600' : 'text-muted-foreground'}`}>
                      {i + 1}
                    </span>
                    <div className="w-10 h-14 rounded flex-shrink-0 bg-primary/10 overflow-hidden">
                      {n.coverUrl ? (
                        <img src={n.coverUrl} alt={n.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full cover-gradient" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate group-hover:text-primary transition-colors">{n.title}</p>
                      <p className="text-xs text-muted-foreground">{n.authorName}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <Flame className="h-3 w-3 text-amber-400" />
                        <span className="text-xs text-amber-400 font-medium">{formatNumber(n.hypeCount)}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Recent Chapters */}
          {recentChapters.length > 0 && (
            <div className="lg:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <h2 className="text-lg font-bold">Lançamentos Recentes</h2>
                </div>
                <Link href="/lancamentos" className="text-xs text-muted-foreground hover:text-primary transition-colors">
                  Ver mais
                </Link>
              </div>
              <div className="space-y-2">
                {recentChapters.map(ch => (
                  <Link key={ch.chapterId} href={`/historias/${ch.novelSlug}/${ch.chapterNumber}`} className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card hover:border-primary/40 hover:bg-accent/50 transition-all group">
                    <div className="w-10 h-14 rounded flex-shrink-0 bg-primary/10 overflow-hidden">
                      {ch.novelCover ? (
                        <img src={ch.novelCover} alt={ch.novelTitle ?? ''} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full cover-gradient" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate group-hover:text-primary transition-colors">{ch.novelTitle}</p>
                      <p className="text-xs text-muted-foreground truncate">
                        Cap. {ch.chapterNumber} — {ch.chapterTitle}
                      </p>
                      <p className="text-xs text-muted-foreground/60 mt-0.5">por {ch.authorName}</p>
                    </div>
                    <span className="text-xs text-muted-foreground flex-shrink-0">
                      {ch.publishedAt ? new Date(ch.publishedAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }) : ''}
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Stats strip */}
        {!isEmpty && (
          <section className="border border-border rounded-xl p-6 bg-card">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
              {[
                { icon: <BookOpen className="h-5 w-5" />, label: 'Novelas', value: formatNumber(featured.length) },
                { icon: <Star className="h-5 w-5 text-gold" />, label: 'Capítulos', value: formatNumber(recentChapters.length) },
                { icon: <Flame className="h-5 w-5 text-amber-400" />, label: 'Hypes Hoje', value: formatNumber(hypeRanking.reduce((a, n) => a + n.hypeCount, 0)) },
                { icon: <TrendingUp className="h-5 w-5 text-primary" />, label: 'Leituras', value: formatNumber(featured.reduce((a, n) => a + n.views, 0)) },
              ].map(s => (
                <div key={s.label} className="flex flex-col items-center gap-1">
                  <div className="text-muted-foreground">{s.icon}</div>
                  <div className="text-2xl font-bold">{s.value}</div>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                </div>
              ))}
            </div>
          </section>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-16 py-8 text-center text-sm text-muted-foreground">
        <div className="mx-auto max-w-7xl px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <span className="font-semibold text-foreground/80">
            <span className="text-primary">Nu</span>veo
          </span>
          <span>Plataforma de webnovels para autores brasileiros e portugueses</span>
          <div className="flex gap-4">
            <Link href="/historias" className="hover:text-primary transition-colors">Histórias</Link>
            <Link href="/ranking" className="hover:text-primary transition-colors">Ranking</Link>
            <Link href="/lancamentos" className="hover:text-primary transition-colors">Lançamentos</Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
