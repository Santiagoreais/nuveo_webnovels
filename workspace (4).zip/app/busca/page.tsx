export const dynamic = 'force-dynamic'

import { Suspense } from 'react'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/Navbar'
import BuscaClient from './BuscaClient'
import { Loader2 } from 'lucide-react'

export default async function BuscaPage() {
  const user = await getSession()
  return (
    <div className="min-h-screen bg-background">
      <Navbar user={user} />
      <Suspense fallback={
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary/50" />
        </div>
      }>
        <BuscaClient />
      </Suspense>
    </div>
  )
}
