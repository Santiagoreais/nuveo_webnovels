'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import Link from 'next/link'
import { Search, X, SlidersHorizontal, BookOpen, Eye, Flame, Star, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react'
import { GENRE_LABELS, STATUS_LABELS, STATUS_COLORS, formatNumber, formatDate, cn } from '@/lib/utils'
import { useRouter, useSearchParams } from 'next/navigation'

type Result = {
  id: number; title: string; slug: string; description: string
  coverUrl: string | null; genre: string; status: string; views: number
  wordCount: number; createdAt: string; authorName: string | null
  authorUsername: string | null; authorAvatar: string | null
  chapterCount: number; avgRating: number; totalVotes: number; hypeCount: number
}

const SORTS = [
  { value: 'recent',  label: 'Mais Recentes' },
  { value: 'views',   label: 'Mais Lidas' },
  { value: 'hype',    label: 'Mais Hype' },
  { value: 'rating',  label: 'Melhor Nota' },
  { value: 'alpha',   label: 'A → Z' },
]

const MIN_CHAPTERS = [
  { value: 0,  label: 'Qualquer' },
  { value: 1,  label: '1+ capítulos' },
  { value: 5,  label: '5+ capítulos' },
  { value: 10, label: '10+ capítulos' },
  { value: 25, label: '25+ capítulos' },
  { value: 50, label: '50+ capítulos' },
]

export default function BuscaClient() {
  const router = useRouter()
  const searchParams = useSearchParams()

  const [q, setQ] = useState(searchParams.get('q') ?? '')
  const [genre, setGenre] = useState(searchParams.get('genre') ?? '')
  const [status, setStatus] = useState(searchParams.get('status') ?? '')
  const [sort, setSort] = useState(searchParams.get('sort') ?? 'recent')
  const [minChapters, setMinChapters] = useState(parseInt(searchParams.get('minChapters') ?? '0'))
  const [page, setPage] = useState(1)

  const [results, setResults] = useState<Result[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(false)
  const [filtersOpen, setFiltersOpen] = useState(false)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const totalPages = Math.ceil(total / 20)
  const hasFilters = genre || status || sort !== 'recent' || minChapters > 0

  const doSearch = useCallback(async (params: {
    q: string; genre: string; status: string; sort: string; minChapters: number; page: number
  }) => {
    setLoading(true)
    try {
      const sp = new URLSearchParams()
      if (params.q) sp.set('q', params.q)
      if (params.genre) sp.set('genre', params.genre)
      if (params.status) sp.set('status', params.status)
      if (params.sort !== 'recent') sp.set('sort', params.sort)
      if (params.minChapters > 0) sp.set('minChapters', String(params.minChapters))
      if (params.page > 1) sp.set('page', String(params.page))
      const res = await fetch(`/api/search?${sp.toString()}`)
      const data = await res.json()
      setResults(data.results ?? [])
      setTotal(data.total ?? 0)
    } finally {
      setLoading(false)
    }
  }, [])

  // Initial load & when page changes
  useEffect(() => {
    doSearch({ q, genre, status, sort, minChapters, page })
  }, [page])

  // Debounced search on filters change (not page)
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      setPage(1)
      doSearch({ q, genre, status, sort, minChapters, page: 1 })
    }, 400)
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current) }
  }, [q, genre, status, sort, minChapters])

  function clearFilters() {
    setGenre(''); setStatus(''); setSort('recent'); setMinChapters(0)
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-1">Busca Avançada</h1>
        <p className="text-muted-foreground text-sm">Encontre webnovels por título, gênero, status e mais</p>
      </div>

      {/* Search bar */}
      <div className="relative mb-4">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <input
          value={q}
          onChange={e => setQ(e.target.value)}
          placeholder="Buscar por título ou sinopse..."
          className="w-full rounded-xl border border-input bg-card pl-12 pr-12 py-3.5 text-base outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all placeholder:text-muted-foreground"
        />
        {q && (
          <button onClick={() => setQ('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar filters — desktop */}
        <aside className="hidden lg:block w-52 flex-shrink-0">
          <FilterPanel
            genre={genre} setGenre={setGenre}
            status={status} setStatus={setStatus}
            sort={sort} setSort={setSort}
            minChapters={minChapters} setMinChapters={setMinChapters}
            hasFilters={!!hasFilters} clearFilters={clearFilters}
          />
        </aside>

        {/* Results */}
        <div className="flex-1 min-w-0">
          {/* Mobile filter toggle + sort */}
          <div className="flex items-center justify-between mb-4 lg:hidden">
            <button
              onClick={() => setFiltersOpen(p => !p)}
              className={cn('flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium transition-colors',
                hasFilters ? 'border-primary/50 bg-primary/10 text-primary' : 'border-border bg-card text-muted-foreground hover:bg-accent')}
            >
              <SlidersHorizontal className="h-4 w-4" />
              Filtros {hasFilters && '(ativos)'}
            </button>
            <p className="text-sm text-muted-foreground">{loading ? '...' : `${total} resultado${total !== 1 ? 's' : ''}`}</p>
          </div>

          {/* Mobile filters panel */}
          {filtersOpen && (
            <div className="lg:hidden mb-4 p-4 rounded-xl border border-border bg-card">
              <FilterPanel
                genre={genre} setGenre={setGenre}
                status={status} setStatus={setStatus}
                sort={sort} setSort={setSort}
                minChapters={minChapters} setMinChapters={setMinChapters}
                hasFilters={!!hasFilters} clearFilters={clearFilters}
              />
            </div>
          )}

          {/* Desktop count */}
          <div className="hidden lg:flex items-center justify-between mb-4">
            <p className="text-sm text-muted-foreground">
              {loading ? 'Buscando...' : `${total} resultado${total !== 1 ? 's' : ''} encontrado${total !== 1 ? 's' : ''}`}
            </p>
            {hasFilters && (
              <button onClick={clearFilters} className="text-xs text-primary hover:underline flex items-center gap-1">
                <X className="h-3 w-3" /> Limpar filtros
              </button>
            )}
          </div>

          {/* Results list */}
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 animate-spin text-primary/50" />
            </div>
          ) : results.length === 0 ? (
            <EmptyState q={q} hasFilters={!!hasFilters} clearFilters={clearFilters} />
          ) : (
            <>
              <div className="space-y-3">
                {results.map(r => <ResultCard key={r.id} novel={r} />)}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 mt-8">
                  <button onClick={() => setPage(p => p - 1)} disabled={page === 1}
                    className="p-2 rounded-lg border border-border hover:bg-accent disabled:opacity-40 transition-colors">
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                  {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
                    const p = totalPages <= 7 ? i + 1 : page <= 4 ? i + 1 : page >= totalPages - 3 ? totalPages - 6 + i : page - 3 + i
                    return (
                      <button key={p} onClick={() => setPage(p)}
                        className={cn('w-9 h-9 rounded-lg text-sm font-medium transition-colors',
                          page === p ? 'bg-primary text-primary-foreground' : 'border border-border hover:bg-accent text-muted-foreground')}>
                        {p}
                      </button>
                    )
                  })}
                  <button onClick={() => setPage(p => p + 1)} disabled={page === totalPages}
                    className="p-2 rounded-lg border border-border hover:bg-accent disabled:opacity-40 transition-colors">
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

// ---- Sub-components ----

function FilterPanel({ genre, setGenre, status, setStatus, sort, setSort, minChapters, setMinChapters, hasFilters, clearFilters }: {
  genre: string; setGenre: (v: string) => void
  status: string; setStatus: (v: string) => void
  sort: string; setSort: (v: string) => void
  minChapters: number; setMinChapters: (v: number) => void
  hasFilters: boolean; clearFilters: () => void
}) {
  return (
    <div className="space-y-5">
      {/* Sort */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Ordenar por</h3>
        <div className="space-y-0.5">
          {SORTS.map(s => (
            <button key={s.value} onClick={() => setSort(s.value)}
              className={cn('w-full text-left px-3 py-2 rounded-lg text-sm transition-colors',
                sort === s.value ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent')}>
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Status */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Status</h3>
        <div className="space-y-0.5">
          <button onClick={() => setStatus('')}
            className={cn('w-full text-left px-3 py-2 rounded-lg text-sm transition-colors',
              !status ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent')}>
            Todos
          </button>
          {Object.entries(STATUS_LABELS).map(([v, l]) => (
            <button key={v} onClick={() => setStatus(status === v ? '' : v)}
              className={cn('w-full text-left px-3 py-2 rounded-lg text-sm transition-colors',
                status === v ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent')}>
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* Genre */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Gênero</h3>
        <div className="space-y-0.5 max-h-60 overflow-y-auto pr-1">
          <button onClick={() => setGenre('')}
            className={cn('w-full text-left px-3 py-2 rounded-lg text-sm transition-colors',
              !genre ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent')}>
            Todos
          </button>
          {Object.entries(GENRE_LABELS).map(([v, l]) => (
            <button key={v} onClick={() => setGenre(genre === v ? '' : v)}
              className={cn('w-full text-left px-3 py-2 rounded-lg text-sm transition-colors',
                genre === v ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent')}>
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* Min chapters */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Mínimo de caps.</h3>
        <div className="space-y-0.5">
          {MIN_CHAPTERS.map(m => (
            <button key={m.value} onClick={() => setMinChapters(m.value)}
              className={cn('w-full text-left px-3 py-2 rounded-lg text-sm transition-colors',
                minChapters === m.value ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent')}>
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {hasFilters && (
        <button onClick={clearFilters}
          className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors">
          <X className="h-3.5 w-3.5" /> Limpar filtros
        </button>
      )}
    </div>
  )
}

function ResultCard({ novel }: { novel: Result }) {
  return (
    <Link href={`/historias/${novel.slug}`}
      className="flex gap-4 p-4 rounded-xl border border-border bg-card hover:border-primary/40 hover:bg-accent/30 transition-all group">
      {/* Cover */}
      <div className="w-16 h-24 rounded-lg flex-shrink-0 overflow-hidden bg-primary/10">
        {novel.coverUrl
          ? <img src={novel.coverUrl} alt={novel.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
          : <div className="w-full h-full cover-gradient flex items-center justify-center"><BookOpen className="h-5 w-5 text-primary/30" /></div>}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className="font-semibold text-base leading-tight group-hover:text-primary transition-colors line-clamp-1">
            {novel.title}
          </h3>
          <span className={cn('flex-shrink-0 text-[10px] font-semibold px-1.5 py-0.5 rounded', STATUS_COLORS[novel.status])}>
            {STATUS_LABELS[novel.status]}
          </span>
        </div>

        <p className="text-xs text-muted-foreground mb-2">
          por <span className="text-foreground/70 font-medium">{novel.authorName}</span>
          {' · '}<span className="text-primary/70">{GENRE_LABELS[novel.genre] ?? novel.genre}</span>
        </p>

        <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed mb-3">
          {novel.description}
        </p>

        <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
          <span className="flex items-center gap-1">
            <BookOpen className="h-3 w-3" />{novel.chapterCount} cap.
          </span>
          <span className="flex items-center gap-1">
            <Eye className="h-3 w-3" />{formatNumber(novel.views)}
          </span>
          <span className="flex items-center gap-1">
            <Flame className="h-3 w-3 text-amber-400" />
            <span className="text-amber-400">{formatNumber(novel.hypeCount)}</span>
          </span>
          <span className="flex items-center gap-1">
            <Star className={cn('h-3 w-3', novel.avgRating > 0 ? 'fill-gold text-gold' : '')} />
            {novel.avgRating > 0 ? novel.avgRating.toFixed(1) : '–'}
          </span>
          {novel.wordCount > 0 && (
            <span>{formatNumber(novel.wordCount)} palavras</span>
          )}
          <span className="hidden sm:inline">{formatDate(novel.createdAt)}</span>
        </div>
      </div>
    </Link>
  )
}

function EmptyState({ q, hasFilters, clearFilters }: { q: string; hasFilters: boolean; clearFilters: () => void }) {
  return (
    <div className="text-center py-20 border border-dashed border-border rounded-xl">
      <Search className="h-12 w-12 text-muted-foreground/40 mx-auto mb-4" />
      <h3 className="font-semibold text-lg mb-2">Nenhum resultado encontrado</h3>
      <p className="text-muted-foreground text-sm mb-6 max-w-sm mx-auto">
        {q ? `Não encontramos novelas para "${q}"` : 'Tente ajustar os filtros para encontrar o que procura'}
        {hasFilters && ' com os filtros atuais'}.
      </p>
      {hasFilters && (
        <button onClick={clearFilters}
          className="px-4 py-2 rounded-lg bg-primary/10 text-primary text-sm font-medium hover:bg-primary/20 transition-colors">
          Limpar filtros
        </button>
      )}
    </div>
  )
}
