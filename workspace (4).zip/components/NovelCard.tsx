import Link from 'next/link'
import { Eye, Star, Flame, BookOpen } from 'lucide-react'
import { cn, formatNumber, GENRE_LABELS, STATUS_LABELS, STATUS_COLORS } from '@/lib/utils'

export type NovelCardData = {
  id: number
  title: string
  slug: string
  description: string
  coverUrl: string | null
  genre: string
  status: string
  views: number
  authorName: string
  authorUsername: string
  avgRating: number
  totalVotes: number
  hypeCount: number
  chapterCount: number
}

export default function NovelCard({ novel, size = 'md' }: { novel: NovelCardData; size?: 'sm' | 'md' | 'lg' }) {
  const isSm = size === 'sm'
  const isLg = size === 'lg'

  return (
    <Link href={`/historias/${novel.slug}`} className="group block">
      <div className={cn(
        'rounded-lg border border-border bg-card overflow-hidden transition-all duration-200',
        'hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5 hover:-translate-y-0.5',
        isLg ? 'flex gap-4 p-3' : ''
      )}>
        {/* Cover */}
        <div className={cn(
          'relative overflow-hidden bg-gradient-to-br from-primary/20 to-background flex-shrink-0',
          isSm ? 'aspect-[3/4] rounded-md' : isLg ? 'w-24 h-36 rounded-md' : 'aspect-[3/4]'
        )}>
          {novel.coverUrl ? (
            <img
              src={novel.coverUrl}
              alt={novel.title}
              className="absolute inset-0 h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="absolute inset-0 cover-gradient flex items-center justify-center">
              <BookOpen className="h-8 w-8 text-primary/40" />
            </div>
          )}
          {/* Status badge */}
          <span className={cn(
            'absolute top-1.5 left-1.5 text-[10px] font-semibold px-1.5 py-0.5 rounded backdrop-blur-sm',
            STATUS_COLORS[novel.status] ?? 'text-muted-foreground bg-muted/80'
          )}>
            {STATUS_LABELS[novel.status] ?? novel.status}
          </span>
        </div>

        {/* Info */}
        <div className={cn('p-3 flex flex-col gap-1.5', isLg ? 'flex-1 p-0' : '')}>
          <div>
            <h3 className={cn(
              'font-semibold leading-tight group-hover:text-primary transition-colors line-clamp-2',
              isSm ? 'text-sm' : 'text-base'
            )}>
              {novel.title}
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              por <span className="text-foreground/70">{novel.authorName}</span>
            </p>
          </div>

          {!isSm && (
            <p className="text-xs text-muted-foreground line-clamp-2">{novel.description}</p>
          )}

          <div className="flex items-center gap-1 flex-wrap mt-auto pt-1">
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-primary/10 text-primary/80 font-medium">
              {GENRE_LABELS[novel.genre] ?? novel.genre}
            </span>
          </div>

          <div className={cn('flex items-center gap-3 text-xs text-muted-foreground', isSm ? 'hidden' : '')}>
            <span className="flex items-center gap-1">
              <Eye className="h-3 w-3" />
              {formatNumber(novel.views)}
            </span>
            <span className="flex items-center gap-1">
              <Star className="h-3 w-3 fill-gold text-gold" />
              {novel.avgRating > 0 ? novel.avgRating.toFixed(1) : '–'}
            </span>
            <span className="flex items-center gap-1">
              <Flame className="h-3 w-3 text-amber-400" />
              {formatNumber(novel.hypeCount)}
            </span>
            <span className="flex items-center gap-1">
              <BookOpen className="h-3 w-3" />
              {novel.chapterCount} cap.
            </span>
          </div>
        </div>
      </div>
    </Link>
  )
}
