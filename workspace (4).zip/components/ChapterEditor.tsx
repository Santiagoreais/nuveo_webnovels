'use client'

import { useRef, useEffect, useCallback, useState } from 'react'
import {
  Bold, Italic, Underline, Strikethrough,
  Heading1, Heading2, Heading3,
  AlignLeft, AlignCenter, AlignRight,
  List, ListOrdered, Quote, Minus,
  Undo, Redo, Type, Eye, EyeOff,
} from 'lucide-react'
import { cn, countWords } from '@/lib/utils'

type Props = {
  value: string
  onChange: (html: string) => void
  placeholder?: string
}

type ToolbarBtn = {
  icon: React.ReactNode
  title: string
  action: () => void
  isActive?: () => boolean
  divider?: boolean
}

export default function ChapterEditor({ value, onChange, placeholder }: Props) {
  const editorRef = useRef<HTMLDivElement>(null)
  const [preview, setPreview] = useState(false)
  const [wordCount, setWordCount] = useState(0)
  const [charCount, setCharCount] = useState(0)
  const isInit = useRef(false)

  // Init content once
  useEffect(() => {
    if (!editorRef.current || isInit.current) return
    editorRef.current.innerHTML = value || ''
    isInit.current = true
    updateCounts()
  }, [])

  function updateCounts() {
    const text = editorRef.current?.innerText ?? ''
    setWordCount(countWords(text))
    setCharCount(text.replace(/\s/g, '').length)
  }

  function exec(cmd: string, val?: string) {
    document.execCommand(cmd, false, val)
    editorRef.current?.focus()
    handleInput()
  }

  function isActive(cmd: string): boolean {
    try { return document.queryCommandState(cmd) } catch { return false }
  }

  function handleInput() {
    if (!editorRef.current) return
    onChange(editorRef.current.innerHTML)
    updateCounts()
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    // Ctrl/Cmd shortcuts
    if (e.ctrlKey || e.metaKey) {
      if (e.key === 'b') { e.preventDefault(); exec('bold') }
      if (e.key === 'i') { e.preventDefault(); exec('italic') }
      if (e.key === 'u') { e.preventDefault(); exec('underline') }
      if (e.key === 'z' && !e.shiftKey) { e.preventDefault(); exec('undo') }
      if (e.key === 'z' && e.shiftKey) { e.preventDefault(); exec('redo') }
      if (e.key === 'y') { e.preventDefault(); exec('redo') }
    }
    // Tab → indent
    if (e.key === 'Tab') {
      e.preventDefault()
      exec('insertHTML', '&nbsp;&nbsp;&nbsp;&nbsp;')
    }
  }

  // Toolbar groups definition
  const buttons: (ToolbarBtn | 'divider')[] = [
    {
      icon: <Undo className="h-4 w-4" />, title: 'Desfazer (Ctrl+Z)',
      action: () => exec('undo'),
    },
    {
      icon: <Redo className="h-4 w-4" />, title: 'Refazer (Ctrl+Y)',
      action: () => exec('redo'),
    },
    'divider',
    {
      icon: <Heading1 className="h-4 w-4" />, title: 'Título H1',
      action: () => exec('formatBlock', '<h1>'),
      isActive: () => document.queryCommandValue('formatBlock') === 'h1',
    },
    {
      icon: <Heading2 className="h-4 w-4" />, title: 'Título H2',
      action: () => exec('formatBlock', '<h2>'),
      isActive: () => document.queryCommandValue('formatBlock') === 'h2',
    },
    {
      icon: <Heading3 className="h-4 w-4" />, title: 'Título H3',
      action: () => exec('formatBlock', '<h3>'),
      isActive: () => document.queryCommandValue('formatBlock') === 'h3',
    },
    {
      icon: <Type className="h-4 w-4" />, title: 'Parágrafo normal',
      action: () => exec('formatBlock', '<p>'),
      isActive: () => document.queryCommandValue('formatBlock') === 'p',
    },
    'divider',
    {
      icon: <Bold className="h-4 w-4" />, title: 'Negrito (Ctrl+B)',
      action: () => exec('bold'),
      isActive: () => isActive('bold'),
    },
    {
      icon: <Italic className="h-4 w-4" />, title: 'Itálico (Ctrl+I)',
      action: () => exec('italic'),
      isActive: () => isActive('italic'),
    },
    {
      icon: <Underline className="h-4 w-4" />, title: 'Sublinhado (Ctrl+U)',
      action: () => exec('underline'),
      isActive: () => isActive('underline'),
    },
    {
      icon: <Strikethrough className="h-4 w-4" />, title: 'Tachado',
      action: () => exec('strikeThrough'),
      isActive: () => isActive('strikeThrough'),
    },
    'divider',
    {
      icon: <AlignLeft className="h-4 w-4" />, title: 'Alinhar à esquerda',
      action: () => exec('justifyLeft'),
      isActive: () => isActive('justifyLeft'),
    },
    {
      icon: <AlignCenter className="h-4 w-4" />, title: 'Centralizar',
      action: () => exec('justifyCenter'),
      isActive: () => isActive('justifyCenter'),
    },
    {
      icon: <AlignRight className="h-4 w-4" />, title: 'Alinhar à direita',
      action: () => exec('justifyRight'),
      isActive: () => isActive('justifyRight'),
    },
    'divider',
    {
      icon: <List className="h-4 w-4" />, title: 'Lista com marcadores',
      action: () => exec('insertUnorderedList'),
      isActive: () => isActive('insertUnorderedList'),
    },
    {
      icon: <ListOrdered className="h-4 w-4" />, title: 'Lista numerada',
      action: () => exec('insertOrderedList'),
      isActive: () => isActive('insertOrderedList'),
    },
    {
      icon: <Quote className="h-4 w-4" />, title: 'Citação',
      action: () => exec('formatBlock', '<blockquote>'),
      isActive: () => document.queryCommandValue('formatBlock') === 'blockquote',
    },
    {
      icon: <Minus className="h-4 w-4" />, title: 'Separador horizontal',
      action: () => exec('insertHorizontalRule'),
    },
  ]

  return (
    <div className="rounded-xl border border-border bg-background overflow-hidden flex flex-col">
      {/* Toolbar */}
      <div className="flex items-center gap-0.5 px-2 py-1.5 border-b border-border bg-card flex-wrap">
        {buttons.map((btn, i) =>
          btn === 'divider'
            ? <div key={i} className="w-px h-5 bg-border mx-1" />
            : (
              <button
                key={i}
                type="button"
                title={btn.title}
                onMouseDown={e => { e.preventDefault(); btn.action() }}
                className={cn(
                  'p-1.5 rounded-md transition-colors text-muted-foreground hover:text-foreground hover:bg-accent',
                  btn.isActive?.() && 'bg-primary/15 text-primary'
                )}
              >
                {btn.icon}
              </button>
            )
        )}

        {/* Preview toggle */}
        <div className="ml-auto flex items-center gap-1">
          <button
            type="button"
            onClick={() => setPreview(p => !p)}
            title={preview ? 'Editar' : 'Pré-visualizar'}
            className={cn(
              'flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors',
              preview
                ? 'bg-primary/15 text-primary'
                : 'text-muted-foreground hover:text-foreground hover:bg-accent'
            )}
          >
            {preview ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            {preview ? 'Editar' : 'Preview'}
          </button>
        </div>
      </div>

      {/* Editor / Preview */}
      <div className="relative min-h-[400px] flex-1">
        {preview ? (
          <div
            className="chapter-content px-6 py-5 min-h-[400px] prose-nuveo"
            dangerouslySetInnerHTML={{ __html: value || '<p class="text-muted-foreground italic">Nenhum conteúdo ainda.</p>' }}
          />
        ) : (
          <>
            {!value && (
              <p className="absolute top-5 left-6 text-muted-foreground/50 pointer-events-none text-base font-reading select-none">
                {placeholder ?? 'Comece a escrever seu capítulo...'}
              </p>
            )}
            <div
              ref={editorRef}
              contentEditable
              suppressContentEditableWarning
              onInput={handleInput}
              onKeyDown={handleKeyDown}
              className="chapter-content editor-area px-6 py-5 min-h-[400px] outline-none"
            />
          </>
        )}
      </div>

      {/* Footer stats */}
      <div className="flex items-center justify-between px-4 py-2 border-t border-border bg-card/50 text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <span><span className="font-semibold text-foreground">{wordCount.toLocaleString()}</span> palavras</span>
          <span><span className="font-semibold text-foreground">{charCount.toLocaleString()}</span> caracteres</span>
          {wordCount > 0 && (
            <span>~{Math.ceil(wordCount / 200)} min de leitura</span>
          )}
        </div>
        <span className="text-[10px] opacity-60">Ctrl+B Negrito · Ctrl+I Itálico · Ctrl+Z Desfazer</span>
      </div>
    </div>
  )
}
