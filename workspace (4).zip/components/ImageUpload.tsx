'use client'

import { useRef, useState } from 'react'
import { Upload, X, Loader2, ImageIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

type Props = {
  value: string
  onChange: (url: string) => void
  type?: 'cover' | 'avatar'
  className?: string
}

export default function ImageUpload({ value, onChange, type = 'cover', className }: Props) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState('')

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setError('')
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('type', type)
      const res = await fetch('/api/upload', { method: 'POST', body: fd })
      const data = await res.json()
      if (!res.ok) { setError(data.error ?? 'Erro no upload'); return }
      onChange(data.url)
    } catch {
      setError('Erro de conexão')
    } finally {
      setUploading(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  const isAvatar = type === 'avatar'

  return (
    <div className={cn('space-y-2', className)}>
      <div
        className={cn(
          'relative group cursor-pointer overflow-hidden border-2 border-dashed border-border hover:border-primary/50 transition-colors bg-card',
          isAvatar ? 'w-24 h-24 rounded-full' : 'w-full aspect-[3/4] max-w-[160px] rounded-xl'
        )}
        onClick={() => inputRef.current?.click()}
      >
        {value ? (
          <>
            <img src={value} alt="preview" className="absolute inset-0 w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              {uploading
                ? <Loader2 className="h-6 w-6 text-white animate-spin" />
                : <Upload className="h-6 w-6 text-white" />
              }
            </div>
          </>
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 text-muted-foreground">
            {uploading
              ? <Loader2 className="h-5 w-5 animate-spin" />
              : <><ImageIcon className="h-5 w-5" />{!isAvatar && <span className="text-[10px] text-center px-2">Clique para fazer upload</span>}</>
            }
          </div>
        )}
      </div>

      {value && (
        <button
          type="button"
          onClick={() => onChange('')}
          className="flex items-center gap-1 text-xs text-muted-foreground hover:text-red-400 transition-colors"
        >
          <X className="h-3 w-3" /> Remover
        </button>
      )}

      {error && <p className="text-xs text-red-400">{error}</p>}
      <p className="text-[10px] text-muted-foreground">JPG, PNG, WEBP · máx 5MB</p>

      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/gif"
        className="hidden"
        onChange={handleFile}
      />
    </div>
  )
}
