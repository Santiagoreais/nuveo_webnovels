'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'
import { BookOpen, Menu, X, Search, LogOut, User, PenSquare, Shield, Settings } from 'lucide-react'
import { cn } from '@/lib/utils'

type NavUser = {
  id: number
  name: string
  username: string
  role: 'reader' | 'author' | 'admin'
  avatarUrl: string | null
} | null

export default function Navbar({ user }: { user: NavUser }) {
  const [open, setOpen] = useState(false)
  const [dropOpen, setDropOpen] = useState(false)
  const pathname = usePathname()

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' })
    // Full reload para limpar estado do servidor
    window.location.href = '/'
  }

  const navLinks = [
    { href: '/historias', label: 'Histórias' },
    { href: '/ranking', label: 'Ranking' },
    { href: '/lancamentos', label: 'Lançamentos' },
  ]

  return (
    <nav className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20 group-hover:bg-primary/30 transition-colors">
              <BookOpen className="h-4 w-4 text-primary" />
            </div>
            <span className="text-xl font-bold tracking-tight">
              <span className="text-primary">Nu</span>
              <span className="text-foreground">veo</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(l => (
              <Link
                key={l.href}
                href={l.href}
                className={cn(
                  'px-3 py-2 text-sm rounded-md transition-colors',
                  pathname === l.href
                    ? 'text-primary bg-primary/10'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                )}
              >
                {l.label}
              </Link>
            ))}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-2">
            <Link href="/busca" className="hidden md:flex items-center gap-2 px-3 h-9 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition-colors text-sm">
              <Search className="h-4 w-4" />
              <span className="hidden lg:inline">Buscar</span>
            </Link>

            {user ? (
              <div className="relative">
                <button
                  onClick={() => setDropOpen(p => !p)}
                  className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-accent transition-colors"
                >
                  <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden">
                    {user.avatarUrl ? (
                      <img src={user.avatarUrl} alt={user.name} className="h-full w-full object-cover" />
                    ) : (
                      <span className="text-sm font-semibold text-primary">{user.name[0].toUpperCase()}</span>
                    )}
                  </div>
                  <span className="hidden md:block text-sm font-medium max-w-24 truncate">{user.name}</span>
                </button>

                {dropOpen && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setDropOpen(false)} />
                    <div className="absolute right-0 mt-1 w-48 rounded-lg border border-border bg-popover shadow-xl z-20 overflow-hidden">
                      <div className="p-2 border-b border-border">
                        <p className="text-sm font-medium truncate">{user.name}</p>
                        <p className="text-xs text-muted-foreground truncate">@{user.username}</p>
                      </div>
                      <div className="p-1">
                        <Link href={`/perfil/${user.username}`} className="flex items-center gap-2 px-3 py-2 text-sm rounded-md hover:bg-accent transition-colors" onClick={() => setDropOpen(false)}>
                          <User className="h-4 w-4" /> Meu Perfil
                        </Link>
                        <Link href="/configuracoes" className="flex items-center gap-2 px-3 py-2 text-sm rounded-md hover:bg-accent transition-colors" onClick={() => setDropOpen(false)}>
                          <Settings className="h-4 w-4" /> Configurações
                        </Link>
                        {(user.role === 'author' || user.role === 'admin') && (
                          <Link href="/minha-area" className="flex items-center gap-2 px-3 py-2 text-sm rounded-md hover:bg-accent transition-colors" onClick={() => setDropOpen(false)}>
                            <PenSquare className="h-4 w-4" /> Minha Área
                          </Link>
                        )}
                        {user.role === 'admin' && (
                          <Link href="/admin" className="flex items-center gap-2 px-3 py-2 text-sm rounded-md hover:bg-accent transition-colors" onClick={() => setDropOpen(false)}>
                            <Shield className="h-4 w-4" /> Admin
                          </Link>
                        )}
                        <div className="my-1 border-t border-border" />
                        <button onClick={() => { logout(); setDropOpen(false) }} className="w-full flex items-center gap-2 px-3 py-2 text-sm rounded-md text-destructive hover:bg-destructive/10 transition-colors">
                          <LogOut className="h-4 w-4" /> Sair
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="hidden md:flex items-center gap-2">
                <Link href="/login" className="px-3 py-1.5 text-sm rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition-colors">
                  Entrar
                </Link>
                <Link href="/registro" className="px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors font-medium">
                  Criar conta
                </Link>
              </div>
            )}

            <button className="md:hidden p-2 rounded-md hover:bg-accent" onClick={() => setOpen(p => !p)}>
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-border bg-background p-4 space-y-1">
          {navLinks.map(l => (
            <Link key={l.href} href={l.href} className="block px-3 py-2 text-sm rounded-md hover:bg-accent transition-colors" onClick={() => setOpen(false)}>
              {l.label}
            </Link>
          ))}
          <Link href="/busca" className="flex items-center gap-2 px-3 py-2 text-sm rounded-md hover:bg-accent transition-colors text-muted-foreground" onClick={() => setOpen(false)}>
            <Search className="h-4 w-4" /> Busca Avançada
          </Link>
          {!user && (
            <div className="pt-2 flex flex-col gap-2">
              <Link href="/login" className="block px-3 py-2 text-sm text-center rounded-md border border-border hover:bg-accent transition-colors" onClick={() => setOpen(false)}>Entrar</Link>
              <Link href="/registro" className="block px-3 py-2 text-sm text-center rounded-md bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-colors" onClick={() => setOpen(false)}>Criar conta</Link>
            </div>
          )}
        </div>
      )}
    </nav>
  )
}
